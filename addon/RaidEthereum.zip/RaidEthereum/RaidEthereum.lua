-- Raid Ethereum: avvisi dei raid della gilda e strumenti per il referente.
--
-- Il referente copia dalla pagina di composizione (bottone "Per l'addon") una riga:
--   RE1|id|raid|inizio|ritrovo|referente|gruppo1;gruppo2;...|panchina   (nomi separati da virgola)
-- e la incolla con /raideth. L'addon la manda agli altri addon della gilda (messaggi addon GUILD).
-- Chi e' nel raid riceve l'avviso 15 minuti prima del ritrovo e all'ora del ritrovo.
-- Il referente puo': invitare tutti quelli online, accendere l'auto-invito al login, sistemare i gruppi.

local PREFIX = "RAIDETH"
local TITOLO = "|cffffd000Raid Ethereum:|r "
local function say(msg) DEFAULT_CHAT_FRAME:AddMessage(TITOLO .. msg) end

local DB
local raidAttivo -- id del raid mostrato nella finestra
local invitati = {} -- nome -> ultimo invito (per non ripeterlo ogni secondo)
local ultimoInvito = -999

-- ---------------------------------------------------------------- dati

local function pulisciNome(n)
  n = tostring(n or ""):gsub("%-.*$", "") -- "Nome-Reame" -> "Nome"
  return n
end

local function leggiRiga(riga)
  riga = tostring(riga or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local p = {}
  for campo in (riga .. "|"):gmatch("([^|]*)|") do p[#p + 1] = campo end
  if p[1] ~= "RE1" or #p < 7 then return nil end
  local r = { id = p[2], raid = p[3], inizio = tonumber(p[4]), ritrovo = tonumber(p[5]), ref = p[6], gruppi = {}, panca = {} }
  if not r.id or r.id == "" or not r.inizio then return nil end
  local g = 0
  for gruppo in (p[7] .. ";"):gmatch("([^;]*);") do
    g = g + 1
    r.gruppi[g] = {}
    for nome in gruppo:gmatch("[^,]+") do table.insert(r.gruppi[g], nome) end
  end
  for nome in (p[8] or ""):gmatch("[^,]+") do table.insert(r.panca, nome) end
  r.riga = riga
  return r
end

-- nome -> gruppo desiderato (panchina = 0)
local function postiDi(r)
  local posti = {}
  for g, lista in ipairs(r.gruppi) do for _, n in ipairs(lista) do posti[n] = g end end
  for _, n in ipairs(r.panca) do posti[n] = posti[n] or 0 end
  return posti
end

local function ordinati()
  local l = {}
  for _, r in pairs(DB.raids) do l[#l + 1] = r end
  table.sort(l, function(a, b) return a.inizio < b.inizio end)
  return l
end

local function pulisciVecchi()
  local ora = time()
  for id, r in pairs(DB.raids) do if r.inizio + 4 * 3600 < ora then DB.raids[id] = nil end end
end

-- ---------------------------------------------------------------- gilda e gruppo

local online = {}
local function aggiornaOnline()
  wipe(online)
  if not IsInGuild() then return end
  for i = 1, GetNumGuildMembers() do
    local nome, _, _, _, _, _, _, _, isOnline = GetGuildRosterInfo(i)
    if nome and isOnline then online[pulisciNome(nome)] = true end
  end
end

local function nelGruppo()
  local n = {}
  n[UnitName("player")] = 0
  if IsInRaid() then
    for i = 1, GetNumGroupMembers() do
      local nome, _, sub = GetRaidRosterInfo(i)
      if nome then n[pulisciNome(nome)] = sub end
    end
  elseif IsInGroup() then
    for i = 1, GetNumSubgroupMembers() do
      local nome = UnitName("party" .. i)
      if nome then n[nome] = 1 end
    end
  end
  return n
end

local function invita(nome)
  if C_PartyInfo and C_PartyInfo.InviteUnit then C_PartyInfo.InviteUnit(nome) else InviteUnit(nome) end
  invitati[nome] = GetTime()
  ultimoInvito = GetTime()
end

local function convertiInRaid()
  if IsInGroup() and not IsInRaid() and UnitIsGroupLeader("player") then
    if C_PartyInfo and C_PartyInfo.ConvertToRaid then C_PartyInfo.ConvertToRaid() else ConvertToRaid() end
  end
end

-- invita chi e' nel raid (non la panchina), online e non ancora nel gruppo
local function invitaOnline(r, silenzioso)
  if not r then return 0 end
  if IsInGroup() and not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") then
    if not silenzioso then say("devi essere capo del gruppo o assistente per invitare.") end
    return 0
  end
  aggiornaOnline()
  local gia, n, posti = nelGruppo(), 0, postiDi(r)
  local maxParty = IsInRaid() and 40 or (IsInGroup() and (5 - GetNumGroupMembers()) or 4)
  for nome, g in pairs(posti) do
    if g > 0 and online[nome] and not gia[nome] and (GetTime() - (invitati[nome] or -999)) > 60 and n < maxParty then
      invita(nome)
      n = n + 1
    end
  end
  if not silenzioso then say(n > 0 and ("inviti mandati: " .. n .. ". Appena qualcuno accetta il gruppo diventa un raid.") or "nessuno da invitare: chi e' online e' gia' nel gruppo.") end
  return n
end

-- sposta ognuno nel gruppo deciso nella pagina di composizione
local function sistemaGruppi(r)
  if not r or not IsInRaid() then say("serve essere in raid.") return end
  if not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") then say("devi essere capo raid o assistente.") return end
  if InCombatLockdown() then say("non in combattimento.") return end
  local posti, giri = postiDi(r), 0
  local function passo()
    giri = giri + 1
    local membri, conta = {}, {}
    for i = 1, GetNumGroupMembers() do
      local nome, _, sub = GetRaidRosterInfo(i)
      if nome then
        membri[#membri + 1] = { i = i, nome = pulisciNome(nome), sub = sub }
        conta[sub] = (conta[sub] or 0) + 1
      end
    end
    local mosso = false
    for _, m in ipairs(membri) do
      local voglio = posti[m.nome]
      if voglio and voglio > 0 and voglio ~= m.sub then
        if (conta[voglio] or 0) < 5 then
          SetRaidSubgroup(m.i, voglio)
        else
          for _, altro in ipairs(membri) do
            if altro.sub == voglio and posti[altro.nome] ~= voglio then SwapRaidSubgroup(m.i, altro.i) break end
          end
        end
        mosso = true
        break -- un cambio alla volta: il roster si aggiorna dopo
      end
    end
    if mosso and giri < 60 then C_Timer.After(0.3, passo)
    elseif not mosso then say("gruppi sistemati.")
    else say("non sono riuscito a sistemare tutti: riprova.") end
  end
  passo()
end

-- ---------------------------------------------------------------- messaggi tra addon (gilda)

local inArrivo = {}
local function manda(r)
  if not IsInGuild() or not r.riga then return end
  local riga, pezzi = r.riga, {}
  for i = 1, #riga, 200 do pezzi[#pezzi + 1] = riga:sub(i, i + 199) end
  for i, pezzo in ipairs(pezzi) do
    C_ChatInfo.SendAddonMessage(PREFIX, "D|" .. r.id .. "|" .. i .. "|" .. #pezzi .. "|" .. pezzo, "GUILD")
  end
  r.mandato = time()
end

local function ricevi(testo, mittente)
  local id, i, n, pezzo = testo:match("^D|([^|]+)|(%d+)|(%d+)|(.*)$")
  if not id then return end
  i, n = tonumber(i), tonumber(n)
  local buf = inArrivo[id] or { n = n, parti = {} }
  inArrivo[id] = buf
  buf.parti[i] = pezzo
  for k = 1, n do if not buf.parti[k] then return end end
  inArrivo[id] = nil
  local r = leggiRiga(table.concat(buf.parti))
  if not r then return end
  local prima = DB.raids[r.id]
  r.da = pulisciNome(mittente)
  r.avvisi = prima and prima.avvisi or {}
  r.mio = prima and prima.mio
  DB.raids[r.id] = r
  local io = UnitName("player")
  if postiDi(r)[io] and not (prima and prima.riga == r.riga) then
    say(("sei nel raid |cffffd000%s|r del %s: ritrovo alle %s."):format(r.raid, date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio)))
  end
end

-- ---------------------------------------------------------------- avvisi "e' ora di gruppare"

local function avvisa(testo)
  RaidNotice_AddMessage(RaidWarningFrame, testo, ChatTypeInfo["RAID_WARNING"])
  PlaySound(SOUNDKIT and SOUNDKIT.RAID_WARNING or 8959, "Master")
  if FlashClientIcon then FlashClientIcon() end
  say(testo)
end

local function controllaAvvisi()
  local ora, io = time(), UnitName("player")
  for _, r in pairs(DB.raids) do
    local posto = postiDi(r)[io]
    local rit = r.ritrovo or r.inizio
    r.avvisi = r.avvisi or {}
    if posto and ora < r.inizio + 3600 then
      local chi = (r.ref and r.ref ~= "") and (" Referente: " .. r.ref .. ".") or ""
      local dove = posto == 0 and " (sei in panchina)" or (" (gruppo " .. posto .. ")")
      if not r.avvisi.pre and ora >= rit - 15 * 60 and ora < rit then
        r.avvisi.pre = true
        avvisa(("Tra 15 minuti si gruppa per %s%s.%s"):format(r.raid, dove, chi))
      end
      if not r.avvisi.ora and ora >= rit then
        r.avvisi.ora = true
        avvisa(("E' ora di gruppare per %s%s!%s"):format(r.raid, dove, chi))
      end
    end
  end
end

-- ---------------------------------------------------------------- finestra

local f = CreateFrame("Frame", "RaidEthereumFrame", UIParent, "BasicFrameTemplateWithInset")
f:SetSize(460, 520)
f:SetPoint("CENTER")
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
f:Hide()
tinsert(UISpecialFrames, "RaidEthereumFrame")
if not f.TitleText then
  f.TitleText = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  f.TitleText:SetPoint("TOP", 0, -5)
end
f.TitleText:SetText("Raid Ethereum")

local function bottone(testo, larg, x, y, fn)
  local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  b:SetSize(larg, 24); b:SetPoint("TOPLEFT", x, y); b:SetText(testo); b:SetScript("OnClick", fn)
  return b
end

local campo = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
campo:SetSize(330, 24); campo:SetPoint("TOPLEFT", 20, -34); campo:SetAutoFocus(false); campo:SetMaxLetters(2000)
local nota = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
nota:SetPoint("TOPLEFT", 18, -60); nota:SetText("Incolla qui la riga \"Per l'addon\" della pagina di composizione")

local testa = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
testa:SetPoint("TOPLEFT", 18, -82); testa:SetJustifyH("LEFT"); testa:SetWidth(424)
local info = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
info:SetPoint("TOPLEFT", 18, -104); info:SetJustifyH("LEFT"); info:SetWidth(424)
local colA = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
colA:SetPoint("TOPLEFT", 18, -128); colA:SetJustifyH("LEFT"); colA:SetJustifyV("TOP"); colA:SetWidth(210); colA:SetHeight(290)
local colB = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
colB:SetPoint("TOPLEFT", 234, -128); colB:SetJustifyH("LEFT"); colB:SetJustifyV("TOP"); colB:SetWidth(210); colB:SetHeight(290)

local function corrente()
  local l = ordinati()
  if raidAttivo and DB.raids[raidAttivo] then return DB.raids[raidAttivo], l end
  raidAttivo = l[1] and l[1].id
  return l[1], l
end

local auto -- checkbox
local function aggiorna()
  if not f:IsShown() then return end
  local r, l = corrente()
  if not r then
    testa:SetText("Nessun raid"); info:SetText("Aspetta che il referente pubblichi i gruppi, oppure incolla tu la riga.")
    colA:SetText(""); colB:SetText(""); return
  end
  aggiornaOnline()
  local gia = nelGruppo()
  local n = 0
  for k, x in ipairs(l) do if x.id == r.id then n = k end end
  testa:SetText(("%s  |cff9aa3ae(%d/%d)|r"):format(r.raid, n, #l))
  info:SetText(("%s · ritrovo %s · inizio %s%s"):format(date("%a %d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio), date("%H:%M", r.inizio),
    (r.ref and r.ref ~= "") and (" · referente " .. r.ref) or ""))
  local function riga(nome)
    if gia[nome] then return "|cffffffff" .. nome .. "|r" end
    if online[nome] then return "|cff40c040" .. nome .. "|r" end
    return "|cff6b7480" .. nome .. "|r"
  end
  local a, b = {}, {}
  for g, lista in ipairs(r.gruppi) do
    if #lista > 0 then
      local t = { "|cffffd000Gruppo " .. g .. "|r" }
      for _, nome in ipairs(lista) do t[#t + 1] = "  " .. riga(nome) end
      local dest = (g % 2 == 1) and a or b
      for _, x in ipairs(t) do dest[#dest + 1] = x end
    end
  end
  if #r.panca > 0 then
    b[#b + 1] = "|cffffd000Panchina|r"
    for _, nome in ipairs(r.panca) do b[#b + 1] = "  " .. riga(nome) end
  end
  b[#b + 1] = " "
  b[#b + 1] = "|cffffffffbianco|r nel gruppo · |cff40c040verde|r online · |cff6b7480grigio|r offline"
  colA:SetText(table.concat(a, "\n")); colB:SetText(table.concat(b, "\n"))
  if auto then auto:SetChecked(DB.auto == r.id) end
end

bottone("Importa", 80, 360, -34, function()
  local r = leggiRiga(campo:GetText())
  if not r then say("riga non valida: copia di nuovo il testo dal bottone \"Per l'addon\".") return end
  local prima = DB.raids[r.id]
  r.avvisi = prima and prima.avvisi or {}
  r.mio = true
  DB.raids[r.id] = r
  raidAttivo = r.id
  campo:SetText(""); campo:ClearFocus()
  manda(r)
  say(("importato %s: mandato agli addon della gilda."):format(r.raid))
  aggiorna()
end)
bottone("‹", 28, 18, -422, function()
  local _, l = corrente()
  for k, x in ipairs(l) do if x.id == raidAttivo then raidAttivo = (l[k - 1] or l[#l]).id break end end
  aggiorna()
end)
bottone("›", 28, 48, -422, function()
  local _, l = corrente()
  for k, x in ipairs(l) do if x.id == raidAttivo then raidAttivo = (l[k + 1] or l[1]).id break end end
  aggiorna()
end)
bottone("Invita online", 120, 82, -422, function() invitaOnline((corrente())) end)
bottone("Sistema gruppi", 120, 206, -422, function() sistemaGruppi((corrente())) end)
bottone("Annuncia", 90, 330, -422, function()
  local r = corrente()
  if r then manda(r) say("raid mandato di nuovo agli addon della gilda.") end
end)
auto = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
auto:SetPoint("TOPLEFT", 16, -452)
auto.etichetta = auto.Text or auto.text
if not auto.etichetta then
  auto.etichetta = auto:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  auto.etichetta:SetPoint("LEFT", auto, "RIGHT", 2, 0)
end
auto.etichetta:SetText("Auto-invito: invita chi e' nel raid appena logga")
auto:SetScript("OnClick", function(self)
  local r = corrente()
  DB.auto = (self:GetChecked() and r) and r.id or nil
  say(DB.auto and ("auto-invito ACCESO per " .. r.raid .. ".") or "auto-invito spento.")
  if DB.auto then invitaOnline(r, true) end
end)
f:SetScript("OnShow", function() if IsInGuild() then C_GuildInfo.GuildRoster() end aggiorna() end)

-- ---------------------------------------------------------------- bottone minimappa, comandi, eventi

local broker
local function iconaStato()
  if broker then broker.icon = DB and DB.auto and "Interface\\Icons\\Ability_Warrior_RallyingCry" or "Interface\\Icons\\INV_Misc_Note_02" end
end

SLASH_RAIDETHEREUM1 = "/raideth"
SlashCmdList.RAIDETHEREUM = function(msg)
  msg = (msg or ""):lower()
  if msg:match("^invita") then invitaOnline((corrente()))
  elseif msg:match("^gruppi") then sistemaGruppi((corrente()))
  else f:SetShown(not f:IsShown()) end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("CHAT_MSG_SYSTEM")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("GUILD_ROSTER_UPDATE")
local giroAuto = 0
ev:SetScript("OnEvent", function(_, evento, a1, a2, a3, a4)
  if evento == "PLAYER_LOGIN" then
    RaidEthereumDB = RaidEthereumDB or {}
    DB = RaidEthereumDB
    DB.raids = DB.raids or {}
    RaidEthereumIconDB = RaidEthereumIconDB or {}
    C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    pulisciVecchi()
    local LDB = LibStub and LibStub("LibDataBroker-1.1", true)
    local icon = LibStub and LibStub("LibDBIcon-1.0", true)
    if LDB and icon then
      broker = LDB:NewDataObject("RaidEthereum", {
        type = "launcher", label = "Raid Ethereum", icon = "Interface\\Icons\\INV_Misc_Note_02",
        OnClick = function(_, tasto)
          if tasto == "RightButton" and DB.auto then DB.auto = nil; iconaStato(); say("auto-invito spento.") aggiorna()
          else f:SetShown(not f:IsShown()) end
        end,
        OnTooltipShow = function(tt)
          tt:AddLine("Raid Ethereum")
          local r = corrente()
          if r then tt:AddLine(("%s %s, ritrovo %s"):format(r.raid, date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio)), 1, 1, 1) end
          tt:AddLine(DB.auto and "Auto-invito: |cff40c040ACCESO|r (clic destro per spegnere)" or "Auto-invito: spento", 1, 1, 1)
          tt:AddLine("Clic: apri la finestra", 0.7, 0.7, 0.7)
        end,
      })
      icon:Register("RaidEthereum", broker, RaidEthereumIconDB)
      iconaStato()
    end
    C_Timer.NewTicker(15, function()
      controllaAvvisi()
      -- il referente rimanda il raid alla gilda ogni 5 minuti, per chi logga dopo
      for _, r in pairs(DB.raids) do
        if r.mio and time() < r.inizio and time() - (r.mandato or 0) > 300 then manda(r) end
      end
      if DB.auto then
        local r = DB.raids[DB.auto]
        if not r or time() > r.inizio + 3 * 3600 then DB.auto = nil
        else
          giroAuto = giroAuto + 1
          if giroAuto % 2 == 0 and IsInGuild() then C_GuildInfo.GuildRoster() end
          invitaOnline(r, true)
        end
      end
      iconaStato()
    end)
    C_Timer.After(5, controllaAvvisi)
  elseif evento == "CHAT_MSG_ADDON" and a1 == PREFIX then
    ricevi(a2, a4)
    aggiorna()
  elseif evento == "CHAT_MSG_SYSTEM" and DB and DB.auto then
    -- "Nome has come online." -> invito subito se e' nel raid
    local nome = a1:match("|Hplayer:([^:|]+)") or a1:match("^(%S+) has come online")
    if nome and a1:find("online") then
      local r = DB.raids[DB.auto]
      nome = pulisciNome(nome)
      if r and (postiDi(r)[nome] or 0) > 0 then C_Timer.After(2, function() invita(nome) end) end
    end
  elseif evento == "GROUP_ROSTER_UPDATE" then
    -- dopo i nostri inviti, appena qualcuno entra il gruppo diventa raid
    if GetTime() - ultimoInvito < 600 then convertiInRaid() end
    aggiorna()
  elseif evento == "GUILD_ROSTER_UPDATE" then
    aggiorna()
  end
end)

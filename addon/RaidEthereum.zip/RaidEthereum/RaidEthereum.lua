-- Raid Ethereum: avvisi dei raid della gilda e strumenti per il referente.
--
-- Quando si pubblicano i gruppi, il bot manda ai referenti su Discord una riga:
--   RE1|id|raid|inizio|ritrovo|referenti|gruppo1;gruppo2;...|panchina   (nomi separati da virgola, referenti separati da +)
-- che si incolla con /raideth. L'addon la manda agli altri addon della gilda (messaggi addon GUILD).
-- All'ora del ritrovo il referente riceve un popup: "Avvia inviti" invita chi e' online e poi chi entra in gioco, fino all'inizio.
-- Chi e' nel raid riceve l'avviso 15 minuti prima del ritrovo e all'ora del ritrovo.
-- Solo i referenti del raid possono: invitare tutti quelli online, accendere l'auto-invito al login, sistemare i gruppi.
-- Se la riga non ha referenti, puo' farlo chi l'ha importata.

local PREFIX = "RAIDETH"
local TITOLO = "|cffffd000Raid Ethereum:|r "
local function say(msg) DEFAULT_CHAT_FRAME:AddMessage(TITOLO .. msg) end

local DB
local raidAttivo -- id del raid mostrato nella finestra
local invitati = {} -- nome -> ultimo invito (per non ripeterlo ogni secondo)
local ultimoInvito = -999

-- ---------------------------------------------------------------- dati

local function pulisciNome(n)
  n = tostring(n or ""):gsub("%-.*$", "") -- "Nome-Reame" -> "Nome"
  return n
end

local function leggiRiga(riga)
  riga = tostring(riga or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local p = {}
  for campo in (riga .. "|"):gmatch("([^|]*)|") do p[#p + 1] = campo end
  if p[1] ~= "RE1" or #p < 7 then return nil end
  local r = { id = p[2], raid = p[3], inizio = tonumber(p[4]), ritrovo = tonumber(p[5]), refs = {}, gruppi = {}, panca = {} }
  for pezzo in (p[6] or ""):gmatch("[^+,]+") do
    local nome = pezzo:gsub("^%s+", ""):gsub("%s+$", "")
    if nome ~= "" then table.insert(r.refs, nome) end
  end
  r.ref = table.concat(r.refs, ", ")
  if not r.id or r.id == "" or not r.inizio then return nil end
  local g = 0
  for gruppo in (p[7] .. ";"):gmatch("([^;]*);") do
    g = g + 1
    r.gruppi[g] = {}
    for nome in gruppo:gmatch("[^,]+") do table.insert(r.gruppi[g], nome) end
  end
  for nome in (p[8] or ""):gmatch("[^,]+") do table.insert(r.panca, nome) end
  r.riga = riga
  return r
end

-- nome -> gruppo desiderato (panchina = 0)
local function postiDi(r)
  local posti = {}
  for g, lista in ipairs(r.gruppi) do for _, n in ipairs(lista) do posti[n] = g end end
  for _, n in ipairs(r.panca) do posti[n] = posti[n] or 0 end
  return posti
end

local function ordinati()
  local l = {}
  for _, r in pairs(DB.raids) do l[#l + 1] = r end
  table.sort(l, function(a, b) return a.inizio < b.inizio end)
  return l
end

local function pulisciVecchi()
  local ora = time()
  for id, r in pairs(DB.raids) do if r.inizio + 4 * 3600 < ora then DB.raids[id] = nil end end
end

-- ---------------------------------------------------------------- gilda e gruppo

local online, classi = {}, {}
local function aggiornaOnline()
  wipe(online)
  if not IsInGuild() then return end
  for i = 1, GetNumGuildMembers() do
    local nome, _, _, _, _, _, _, _, isOnline, _, classe = GetGuildRosterInfo(i)
    if nome then
      nome = pulisciNome(nome)
      if isOnline then online[nome] = true end
      if classe then classi[nome] = classe end
    end
  end
end

local function nelGruppo()
  local n = {}
  n[UnitName("player")] = 0
  if IsInRaid() then
    for i = 1, GetNumGroupMembers() do
      local nome, _, sub = GetRaidRosterInfo(i)
      if nome then n[pulisciNome(nome)] = sub end
    end
  elseif IsInGroup() then
    for i = 1, GetNumSubgroupMembers() do
      local nome = UnitName("party" .. i)
      if nome then n[nome] = 1 end
    end
  end
  return n
end

local function invita(nome)
  if C_PartyInfo and C_PartyInfo.InviteUnit then C_PartyInfo.InviteUnit(nome) else InviteUnit(nome) end
  invitati[nome] = GetTime()
  ultimoInvito = GetTime()
end

local function convertiInRaid()
  if IsInGroup() and not IsInRaid() and UnitIsGroupLeader("player") then
    if C_PartyInfo and C_PartyInfo.ConvertToRaid then C_PartyInfo.ConvertToRaid() else ConvertToRaid() end
  end
end

-- posso fare da referente per questo raid?
local function sonoReferente(r)
  if not r then return false end
  if not r.refs or #r.refs == 0 then return r.mio and true or false end
  local io = UnitName("player"):lower()
  for _, n in ipairs(r.refs) do if n:lower() == io then return true end end
  return false
end
local function soloReferenti(r)
  if sonoReferente(r) then return true end
  say(r and ("solo i referenti di " .. r.raid .. " (" .. (r.ref ~= "" and r.ref or "chi ha importato la riga") .. ") possono farlo.") or "nessun raid.")
  return false
end

-- invita chi e' nel raid (non la panchina), online e non ancora nel gruppo
local function invitaOnline(r, silenzioso)
  if not r then return 0 end
  if not sonoReferente(r) then
    if not silenzioso then soloReferenti(r) end
    return 0
  end
  if IsInGroup() and not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") then
    if not silenzioso then say("devi essere capo del gruppo o assistente per invitare.") end
    return 0
  end
  aggiornaOnline()
  local gia, n, posti = nelGruppo(), 0, postiDi(r)
  local maxParty = IsInRaid() and 40 or (IsInGroup() and (5 - GetNumGroupMembers()) or 4)
  for nome, g in pairs(posti) do
    if g > 0 and online[nome] and not gia[nome] and (GetTime() - (invitati[nome] or -999)) > 60 and n < maxParty then
      invita(nome)
      n = n + 1
    end
  end
  if not silenzioso then say(n > 0 and ("inviti mandati: " .. n .. ". Appena qualcuno accetta il gruppo diventa un raid.") or "nessuno da invitare: chi e' online e' gia' nel gruppo.") end
  return n
end

-- sposta ognuno nel gruppo deciso nella pagina di composizione
local function sistemaGruppi(r)
  if not r or not soloReferenti(r) then return end
  if not IsInRaid() then say("serve essere in raid.") return end
  if not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") then say("devi essere capo raid o assistente.") return end
  if InCombatLockdown() then say("non in combattimento.") return end
  local posti, giri = postiDi(r), 0
  local function passo()
    giri = giri + 1
    local membri, conta = {}, {}
    for i = 1, GetNumGroupMembers() do
      local nome, _, sub = GetRaidRosterInfo(i)
      if nome then
        membri[#membri + 1] = { i = i, nome = pulisciNome(nome), sub = sub }
        conta[sub] = (conta[sub] or 0) + 1
      end
    end
    local mosso = false
    for _, m in ipairs(membri) do
      local voglio = posti[m.nome]
      if voglio and voglio > 0 and voglio ~= m.sub then
        if (conta[voglio] or 0) < 5 then
          SetRaidSubgroup(m.i, voglio)
        else
          for _, altro in ipairs(membri) do
            if altro.sub == voglio and posti[altro.nome] ~= voglio then SwapRaidSubgroup(m.i, altro.i) break end
          end
        end
        mosso = true
        break -- un cambio alla volta: il roster si aggiorna dopo
      end
    end
    if mosso and giri < 60 then C_Timer.After(0.3, passo)
    elseif not mosso then say("gruppi sistemati.")
    else say("non sono riuscito a sistemare tutti: riprova.") end
  end
  passo()
end

-- ---------------------------------------------------------------- messaggi tra addon (gilda)

local inArrivo = {}
local function manda(r)
  if not IsInGuild() or not r.riga then return end
  local riga, pezzi = r.riga, {}
  for i = 1, #riga, 200 do pezzi[#pezzi + 1] = riga:sub(i, i + 199) end
  for i, pezzo in ipairs(pezzi) do
    C_ChatInfo.SendAddonMessage(PREFIX, "D|" .. r.id .. "|" .. i .. "|" .. #pezzi .. "|" .. pezzo, "GUILD")
  end
  r.mandato = time()
end

local function ricevi(testo, mittente)
  local id, i, n, pezzo = testo:match("^D|([^|]+)|(%d+)|(%d+)|(.*)$")
  if not id then return end
  i, n = tonumber(i), tonumber(n)
  local buf = inArrivo[id] or { n = n, parti = {} }
  inArrivo[id] = buf
  buf.parti[i] = pezzo
  for k = 1, n do if not buf.parti[k] then return end end
  inArrivo[id] = nil
  local r = leggiRiga(table.concat(buf.parti))
  if not r then return end
  local prima = DB.raids[r.id]
  r.da = pulisciNome(mittente)
  r.avvisi = prima and prima.avvisi or {}
  r.mio = prima and prima.mio
  DB.raids[r.id] = r
  local io = UnitName("player")
  if postiDi(r)[io] and not (prima and prima.riga == r.riga) then
    say(("sei nel raid |cffffd000%s|r del %s: ritrovo alle %s."):format(r.raid, date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio)))
  end
end

-- ---------------------------------------------------------------- avvisi "e' ora di gruppare"

local function avvisa(testo)
  RaidNotice_AddMessage(RaidWarningFrame, testo, ChatTypeInfo["RAID_WARNING"])
  PlaySound(SOUNDKIT and SOUNDKIT.RAID_WARNING or 8959, "Master")
  if FlashClientIcon then FlashClientIcon() end
  say(testo)
end

local function controllaAvvisi()
  local ora, io = time(), UnitName("player")
  for _, r in pairs(DB.raids) do
    local posto = postiDi(r)[io]
    local rit = r.ritrovo or r.inizio
    r.avvisi = r.avvisi or {}
    if posto and ora < r.inizio + 3600 then
      local chi = (r.ref and r.ref ~= "") and ((#r.refs > 1 and " Referenti: " or " Referente: ") .. r.ref .. ".") or ""
      local dove = posto == 0 and " (sei in panchina)" or (" (gruppo " .. posto .. ")")
      if not r.avvisi.pre and ora >= rit - 15 * 60 and ora < rit then
        r.avvisi.pre = true
        avvisa(("Tra 15 minuti si gruppa per %s%s.%s"):format(r.raid, dove, chi))
      end
      if not r.avvisi.ora and ora >= rit then
        r.avvisi.ora = true
        avvisa(("E' ora di gruppare per %s%s!%s"):format(r.raid, dove, chi))
      end
    end
  end
end

-- ---------------------------------------------------------------- grafica
-- Stile piatto e scuro (sul modello degli addon moderni tipo ElvUI): pannelli neri trasparenti, bordo sottile,
-- oro Ethereum per titoli e bottoni principali, nomi nei colori di classe.

local TMPL = BackdropTemplateMixin and "BackdropTemplate" or nil
local ORO = { 1, 0.82, 0 }
local function pannello(parent, r, g, b, a, bordo)
  local p = CreateFrame("Frame", nil, parent, TMPL)
  p:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  p:SetBackdropColor(r or 0.05, g or 0.06, b or 0.08, a or 0.94)
  local c = bordo or { 0.17, 0.2, 0.26 }
  p:SetBackdropBorderColor(c[1], c[2], c[3], 1)
  return p
end
local function testo(parent, font, x, y, larg, punto)
  local t = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlightSmall")
  t:SetPoint(punto or "TOPLEFT", x or 0, y or 0)
  t:SetJustifyH("LEFT")
  if larg then t:SetWidth(larg) end
  return t
end
-- bottone piatto: principale = oro con testo scuro, normale = grigio scuro
local function bottonePiatto(parent, etichetta, larg, alto, principale, fn)
  local b = CreateFrame("Button", nil, parent, TMPL)
  b:SetSize(larg, alto or 24)
  b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  b.principale = principale
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  b.t:SetPoint("CENTER"); b.t:SetText(etichetta)
  function b:Colora(attivo)
    if not self:IsEnabled() then
      self:SetBackdropColor(0.1, 0.1, 0.12, 1); self:SetBackdropBorderColor(0.2, 0.2, 0.24, 1); self.t:SetTextColor(0.4, 0.4, 0.45)
    elseif self.principale then
      self:SetBackdropColor(ORO[1], ORO[2], ORO[3], attivo and 1 or 0.9); self:SetBackdropBorderColor(1, 0.9, 0.4, 1); self.t:SetTextColor(0.1, 0.08, 0)
    else
      self:SetBackdropColor(0.12, 0.14, 0.18, 1); self:SetBackdropBorderColor(attivo and ORO[1] or 0.25, attivo and ORO[2] or 0.28, attivo and ORO[3] or 0.34, 1); self.t:SetTextColor(0.92, 0.9, 0.85)
    end
  end
  b:SetScript("OnEnter", function(self) self:Colora(true) end)
  b:SetScript("OnLeave", function(self) self:Colora(false) end)
  b:SetScript("OnEnable", function(self) self:Colora(false) end)
  b:SetScript("OnDisable", function(self) self:Colora(false) end)
  b:SetScript("OnClick", fn)
  b:Colora(false)
  return b
end

-- ---------------------------------------------------------------- popup "e' ora di far partire gli inviti"

local pop = pannello(UIParent, 0.04, 0.05, 0.07, 0.97, { ORO[1], ORO[2], ORO[3] })
pop:SetSize(380, 170); pop:SetPoint("TOP", 0, -140); pop:SetFrameStrata("DIALOG"); pop:Hide()
pop:EnableMouse(true); pop:SetMovable(true); pop:RegisterForDrag("LeftButton")
pop:SetScript("OnDragStart", pop.StartMoving); pop:SetScript("OnDragStop", pop.StopMovingOrSizing)
local popIcona = pop:CreateTexture(nil, "ARTWORK")
popIcona:SetSize(48, 48); popIcona:SetPoint("TOPLEFT", 16, -16); popIcona:SetTexture("Interface\\Icons\\Ability_Warrior_RallyingCry")
local popTitolo = testo(pop, "GameFontNormalLarge", 76, -16, 290)
local popSotto = testo(pop, "GameFontHighlight", 76, -40, 290)
local popInfo = testo(pop, "GameFontDisableSmall", 76, -62, 290)
local popRaid
local popSi = bottonePiatto(pop, "Avvia inviti", 160, 30, true, function()
  local r = popRaid; pop:Hide()
  if not r then return end
  DB.auto = r.id
  say(("inviti automatici ACCESI per %s fino alle %s."):format(r.raid, date("%H:%M", r.inizio)))
  invitaOnline(r)
end)
popSi:SetPoint("BOTTOMLEFT", 16, 16)
local popNo = bottonePiatto(pop, "Non ora", 120, 30, false, function() pop:Hide() say("ok: puoi avviarli quando vuoi da /raideth.") end)
popNo:SetPoint("BOTTOMRIGHT", -16, 16)

local function mostraPopup(r)
  popRaid = r
  aggiornaOnline()
  local tot, on = 0, 0
  for nome, g in pairs(postiDi(r)) do if g > 0 then tot = tot + 1; if online[nome] then on = on + 1 end end end
  popTitolo:SetText("E' ora di gruppare!")
  popSotto:SetText(("%s · inizio alle %s"):format(r.raid, date("%H:%M", r.inizio)))
  popInfo:SetText(("Online adesso: %d su %d. Invito subito chi c'e' e poi chi entra in gioco, fino all'inizio del raid."):format(on, tot))
  pop:Show()
  PlaySound(SOUNDKIT and SOUNDKIT.READY_CHECK or 8960, "Master")
  if FlashClientIcon then FlashClientIcon() end
end

-- ---------------------------------------------------------------- finestra principale

local f = pannello(UIParent)
f:SetSize(500, 600); f:SetPoint("CENTER"); f:SetFrameStrata("HIGH")
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
f:Hide()
_G.RaidEthereumFrame = f
tinsert(UISpecialFrames, "RaidEthereumFrame")

local barra = pannello(f, 0.08, 0.09, 0.12, 1)
barra:SetPoint("TOPLEFT", 1, -1); barra:SetPoint("TOPRIGHT", -1, -1); barra:SetHeight(30)
local logo = barra:CreateTexture(nil, "ARTWORK"); logo:SetSize(20, 20); logo:SetPoint("LEFT", 8, 0); logo:SetTexture("Interface\\Icons\\INV_Misc_Note_02")
local titolo = testo(barra, "GameFontNormal", 34, 0, nil, "LEFT"); titolo:SetText("RAID ETHEREUM")
local chiudi = bottonePiatto(barra, "x", 22, 22, false, function() f:Hide() end); chiudi:SetPoint("RIGHT", -4, 0)

-- incolla la stringa ricevuta su Discord
local boxImp = pannello(f, 0.03, 0.035, 0.05, 1)
boxImp:SetPoint("TOPLEFT", 12, -42); boxImp:SetSize(380, 26)
local campo = CreateFrame("EditBox", nil, boxImp)
campo:SetPoint("TOPLEFT", 6, -4); campo:SetPoint("BOTTOMRIGHT", -6, 4)
campo:SetFontObject("GameFontHighlightSmall"); campo:SetAutoFocus(false); campo:SetMaxLetters(3000)
campo:SetScript("OnEscapePressed", campo.ClearFocus)
local suggerimento = testo(boxImp, "GameFontDisableSmall", 8, 0, 360, "LEFT"); suggerimento:SetText("Incolla qui la stringa che il bot ti ha mandato su Discord")
campo:SetScript("OnTextChanged", function(self) suggerimento:SetShown(self:GetText() == "") end)

-- scheda del raid
local nomeRaid = testo(f, "GameFontNormalHuge", 14, -82, 470)
local quando = testo(f, "GameFontHighlight", 14, -110, 470)
local chiRef = testo(f, "GameFontDisableSmall", 14, -128, 470)
local stato = testo(f, "GameFontHighlightSmall", 14, -146, 470)

-- interruttore dell'invito automatico
local riga = pannello(f, 0.07, 0.08, 0.11, 1)
riga:SetPoint("TOPLEFT", 12, -166); riga:SetPoint("TOPRIGHT", -12, -166); riga:SetHeight(40)
local autoTesto = testo(riga, "GameFontHighlight", 10, 0, 330, "LEFT")
local interruttore = CreateFrame("Button", nil, riga, TMPL)
interruttore:SetSize(64, 24); interruttore:SetPoint("RIGHT", -10, 0)
interruttore:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
interruttore.pallino = interruttore:CreateTexture(nil, "OVERLAY"); interruttore.pallino:SetSize(20, 20); interruttore.pallino:SetColorTexture(1, 1, 1, 1)
interruttore.t = interruttore:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")

-- gruppi: 8 riquadri da 5, in due colonne
local riquadri = {}
for g = 1, 8 do
  local q = pannello(f, 0.07, 0.08, 0.11, 1)
  q:SetSize(232, 82)
  q:SetPoint("TOPLEFT", 12 + ((g - 1) % 2) * 244, -214 - math.floor((g - 1) / 2) * 88)
  q.titolo = testo(q, "GameFontNormalSmall", 6, -4)
  q.titolo:SetText("Gruppo " .. g)
  q.righe = {}
  for i = 1, 5 do q.righe[i] = testo(q, "GameFontHighlightSmall", 8, -6 - i * 13, 218) end
  riquadri[g] = q
end
local panca = testo(f, "GameFontHighlightSmall", 14, -568 + 40, 470)
local legenda = testo(f, "GameFontDisableSmall", 14, -582 + 40, 470)
legenda:SetText("|TInterface\\RaidFrame\\ReadyCheck-Ready:12|t nel gruppo    |TInterface\\COMMON\\Indicator-Green:12|t online    |TInterface\\COMMON\\Indicator-Gray:12|t offline")

local function corrente()
  local l = ordinati()
  if raidAttivo and DB.raids[raidAttivo] then return DB.raids[raidAttivo], l end
  raidAttivo = l[1] and l[1].id
  return l[1], l
end

local bInvita, bGruppi, bAnnuncia, bPrima, bDopo
local function aggiorna()
  if not f:IsShown() then return end
  local r, l = corrente()
  local ref = r and sonoReferente(r)
  for _, b in ipairs({ bInvita, bGruppi }) do if b then b:SetEnabled(ref and true or false) end end
  interruttore:SetEnabled(ref and true or false)
  if not r then
    nomeRaid:SetText("Nessun raid")
    quando:SetText("Incolla la stringa che ti ha mandato il bot quando sono stati pubblicati i gruppi.")
    chiRef:SetText(""); stato:SetText(""); panca:SetText("")
    for g = 1, 8 do riquadri[g]:Hide() end
    autoTesto:SetText("Invito automatico"); return
  end
  aggiornaOnline()
  local gia = nelGruppo()
  local pos = 0
  for k, x in ipairs(l) do if x.id == r.id then pos = k end end
  nomeRaid:SetText(r.raid .. (#l > 1 and ("  |cff9aa3ae" .. pos .. "/" .. #l .. "|r") or ""))
  quando:SetText(("%s   |cffffd000Ritrovo|r %s   |cffffd000Inizio|r %s"):format(date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio - 1800), date("%H:%M", r.inizio)))
  chiRef:SetText((r.ref and r.ref ~= "") and ((#r.refs > 1 and "Referenti: " or "Referente: ") .. r.ref) or "Referente: chi ha importato la stringa")
  local tot, on, dentro = 0, 0, 0
  local function nomeColorato(nome)
    local c = classi[nome] and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classi[nome]]
    local pallino = gia[nome] and "|TInterface\\RaidFrame\\ReadyCheck-Ready:12|t " or online[nome] and "|TInterface\\COMMON\\Indicator-Green:12|t " or "|TInterface\\COMMON\\Indicator-Gray:12|t "
    local col = c and ("|cff%02x%02x%02x"):format(math.floor(c.r * 255 + 0.5), math.floor(c.g * 255 + 0.5), math.floor(c.b * 255 + 0.5)) or (online[nome] and "|cffe9e3d2" or "|cff6b7480")
    if not online[nome] and not gia[nome] then col = "|cff6b7480" end
    return pallino .. col .. nome .. "|r"
  end
  for g = 1, 8 do
    local lista = r.gruppi[g] or {}
    local q = riquadri[g]
    if #lista > 0 or g <= math.max(1, #r.gruppi) then
      q:Show()
      for i = 1, 5 do
        local nome = lista[i]
        q.righe[i]:SetText(nome and nomeColorato(nome) or "")
        if nome then tot = tot + 1; if online[nome] then on = on + 1 end; if gia[nome] then dentro = dentro + 1 end end
      end
    else
      q:Hide()
    end
  end
  local p = {}
  for _, nome in ipairs(r.panca) do p[#p + 1] = nomeColorato(nome) end
  panca:SetText(#p > 0 and ("|cffffd000Panchina|r  " .. table.concat(p, "  ")) or "")
  stato:SetText(("Online |cff40c040%d|r su %d   ·   nel gruppo |cffffffff%d|r"):format(on, tot, dentro))
  -- interruttore
  local acceso = DB.auto == r.id
  interruttore:SetBackdropColor(acceso and 0.15 or 0.12, acceso and 0.55 or 0.13, acceso and 0.2 or 0.16, 1)
  interruttore:SetBackdropBorderColor(acceso and 0.3 or 0.25, acceso and 0.8 or 0.28, acceso and 0.35 or 0.34, 1)
  interruttore.pallino:ClearAllPoints(); interruttore.pallino:SetPoint(acceso and "RIGHT" or "LEFT", acceso and -2 or 2, 0)
  interruttore.t:ClearAllPoints(); interruttore.t:SetPoint(acceso and "LEFT" or "RIGHT", acceso and 8 or -8, 0)
  interruttore.t:SetText(acceso and "ON" or "OFF")
  autoTesto:SetText(ref and ("Invito automatico  |cff9aa3aedal ritrovo fino alle " .. date("%H:%M", r.inizio) .. "|r")
    or "|cff6b7480Invito automatico: solo per i referenti|r")
end

interruttore:SetScript("OnClick", function()
  local r = corrente()
  if not r or not soloReferenti(r) then return end
  DB.auto = DB.auto ~= r.id and r.id or nil
  say(DB.auto and ("inviti automatici ACCESI per %s fino alle %s."):format(r.raid, date("%H:%M", r.inizio)) or "inviti automatici spenti.")
  if DB.auto then invitaOnline(r, true) end
  aggiorna()
end)

local bImporta = bottonePiatto(f, "Importa", 84, 26, true, function()
  local r = leggiRiga(campo:GetText())
  if not r then say("stringa non valida: copiala di nuovo dal messaggio del bot.") return end
  local prima = DB.raids[r.id]
  r.avvisi = prima and prima.avvisi or {}
  r.mio = true
  DB.raids[r.id] = r
  raidAttivo = r.id
  campo:SetText(""); campo:ClearFocus()
  manda(r)
  say(("importato %s: all'ora del ritrovo ti chiedo se far partire gli inviti."):format(r.raid))
  aggiorna()
end)
bImporta:SetPoint("TOPRIGHT", -12, -42)

bPrima = bottonePiatto(f, "<", 26, 26, false, function()
  local _, l = corrente()
  for k, x in ipairs(l) do if x.id == raidAttivo then raidAttivo = (l[k - 1] or l[#l]).id break end end
  aggiorna()
end)
bPrima:SetPoint("BOTTOMLEFT", 12, 12)
bDopo = bottonePiatto(f, ">", 26, 26, false, function()
  local _, l = corrente()
  for k, x in ipairs(l) do if x.id == raidAttivo then raidAttivo = (l[k + 1] or l[1]).id break end end
  aggiorna()
end)
bDopo:SetPoint("LEFT", bPrima, "RIGHT", 4, 0)
bInvita = bottonePiatto(f, "Invita ora", 120, 26, true, function() invitaOnline((corrente())) end)
bInvita:SetPoint("LEFT", bDopo, "RIGHT", 10, 0)
bGruppi = bottonePiatto(f, "Sistema gruppi", 130, 26, false, function() sistemaGruppi((corrente())) end)
bGruppi:SetPoint("LEFT", bInvita, "RIGHT", 6, 0)
bAnnuncia = bottonePiatto(f, "Annuncia", 100, 26, false, function()
  local r = corrente()
  if r then manda(r) say("raid mandato di nuovo agli addon della gilda.") end
end)
bAnnuncia:SetPoint("LEFT", bGruppi, "RIGHT", 6, 0)
f:SetScript("OnShow", function() if IsInGuild() then C_GuildInfo.GuildRoster() end aggiorna() end)

-- ---------------------------------------------------------------- bottone minimappa, comandi, eventi

local broker
local function iconaStato()
  if broker then broker.icon = DB and DB.auto and "Interface\\Icons\\Ability_Warrior_RallyingCry" or "Interface\\Icons\\INV_Misc_Note_02" end
end

SLASH_RAIDETHEREUM1 = "/raideth"
SlashCmdList.RAIDETHEREUM = function(msg)
  msg = (msg or ""):lower()
  if msg:match("^invita") then invitaOnline((corrente()))
  elseif msg:match("^gruppi") then sistemaGruppi((corrente()))
  else f:SetShown(not f:IsShown()) end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("CHAT_MSG_SYSTEM")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("GUILD_ROSTER_UPDATE")
local giroAuto = 0
ev:SetScript("OnEvent", function(_, evento, a1, a2, a3, a4)
  if evento == "PLAYER_LOGIN" then
    RaidEthereumDB = RaidEthereumDB or {}
    DB = RaidEthereumDB
    DB.raids = DB.raids or {}
    RaidEthereumIconDB = RaidEthereumIconDB or {}
    C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    pulisciVecchi()
    local LDB = LibStub and LibStub("LibDataBroker-1.1", true)
    local icon = LibStub and LibStub("LibDBIcon-1.0", true)
    if LDB and icon then
      broker = LDB:NewDataObject("RaidEthereum", {
        type = "launcher", label = "Raid Ethereum", icon = "Interface\\Icons\\INV_Misc_Note_02",
        OnClick = function(_, tasto)
          if tasto == "RightButton" and DB.auto then DB.auto = nil; iconaStato(); say("inviti automatici spenti.") aggiorna()
          else f:SetShown(not f:IsShown()) end
        end,
        OnTooltipShow = function(tt)
          tt:AddLine("Raid Ethereum")
          local r = corrente()
          if r then tt:AddLine(("%s %s, ritrovo %s"):format(r.raid, date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio)), 1, 1, 1) end
          tt:AddLine(DB.auto and "Inviti automatici: |cff40c040ACCESI|r (clic destro per spegnere)" or "Inviti automatici: spenti", 1, 1, 1)
          tt:AddLine("Clic: apri la finestra", 0.7, 0.7, 0.7)
        end,
      })
      icon:Register("RaidEthereum", broker, RaidEthereumIconDB)
      iconaStato()
    end
    C_Timer.NewTicker(15, function()
      controllaAvvisi()
      local ora = time()
      for _, r in pairs(DB.raids) do
        -- il referente rimanda il raid alla gilda ogni 5 minuti, per chi logga dopo
        if r.mio and ora < r.inizio and ora - (r.mandato or 0) > 300 then manda(r) end
        -- all'ora del ritrovo: popup per far partire gli inviti (solo ai referenti, una volta)
        local rit = r.ritrovo or (r.inizio - 1800)
        r.avvisi = r.avvisi or {}
        if sonoReferente(r) and ora >= rit and ora < r.inizio and not r.avvisi.popup and DB.auto ~= r.id then
          r.avvisi.popup = true
          mostraPopup(r)
        end
      end
      if DB.auto then
        local r = DB.raids[DB.auto]
        if not r or not sonoReferente(r) then DB.auto = nil
        elseif ora >= r.inizio then
          DB.auto = nil
          avvisa(("Inviti automatici finiti: %s sta per iniziare."):format(r.raid))
        else
          giroAuto = giroAuto + 1
          if giroAuto % 2 == 0 and IsInGuild() then C_GuildInfo.GuildRoster() end
          invitaOnline(r, true)
        end
      end
      iconaStato()
      aggiorna()
    end)
    C_Timer.After(5, controllaAvvisi)
  elseif evento == "CHAT_MSG_ADDON" and a1 == PREFIX then
    ricevi(a2, a4)
    aggiorna()
  elseif evento == "CHAT_MSG_SYSTEM" and DB and DB.auto then
    -- "Nome has come online." -> invito subito se e' nel raid
    local nome = a1:match("|Hplayer:([^:|]+)") or a1:match("^(%S+) has come online")
    if nome and a1:find("online") then
      local r = DB.raids[DB.auto]
      nome = pulisciNome(nome)
      if r and sonoReferente(r) and time() < r.inizio and (postiDi(r)[nome] or 0) > 0 then C_Timer.After(2, function() invita(nome) end) end
    end
  elseif evento == "GROUP_ROSTER_UPDATE" then
    -- dopo i nostri inviti, appena qualcuno entra il gruppo diventa raid
    if GetTime() - ultimoInvito < 600 then convertiInRaid() end
    aggiorna()
  elseif evento == "GUILD_ROSTER_UPDATE" then
    aggiorna()
  end
end)

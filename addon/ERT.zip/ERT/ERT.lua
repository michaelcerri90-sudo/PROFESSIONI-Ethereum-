-------------------------------------------------------------------------------
-- ERT - Ethereum Raid Tools
--
-- Raid: i raid pubblicati dal bot di Discord (riga RE1 incollata dal referente
--       o portata da solo dal programma ERT-Ponte). Avvisi di ritrovo per chi e' nel raid;
--       per i referenti: popup al ritrovo (permesso), annuncio in gilda, un invito a chi e' online
--       (se rifiuta non insiste), invito istantaneo a chi entra in gioco fino all'inizio,
--       invito a chi in lista sussurra "inv", sistema i gruppi.
-- Presenze: un officer sceglie il raid e fa l'appello alla gilda; chi ha ERT
--       risponde "ci sono / non ci sono" da un popup. Le risposte si salvano per
--       Discord: le porta ERT-Ponte dopo un /reload.
-- Opzioni: interruttori (acceso/spento, minimappa, avvisi, popup, suoni).
--
-- Riga RE1: RE1|id|raid|inizio|ritrovo|referenti(+)|gruppo1;gruppo2;...|panchina
-- Messaggi tra addon (prefisso ERT, canale gilda):
--   D|id|i|n|pezzo        un raid (a pezzi da 200 caratteri)
--   A|req|chiave|nome|inizio   appello presenze (dall'officer a tutta la gilda)
--   R|req|si / R|req|no   risposta all'appello (sussurro all'officer)
--   I|id                  un referente ha avviato gli inviti di quel raid (gli altri referenti non li ripetono)
-------------------------------------------------------------------------------
local PREFIX = "ERT"
local VERSIONE = "3.2"
local function say(msg) DEFAULT_CHAT_FRAME:AddMessage("|cffffd000ERT:|r " .. msg) end

local DB
local raidAttivo
local invitati = {}
local ultimoInvito = -999

local function opz(k) return not DB or DB.opz == nil or DB.opz[k] ~= false end
local function attivo() return not DB or DB.enabled ~= false end
local function suono(id) PlaySound(id, "Master") end
local Chat = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage

-- messaggi di sistema del gioco (nella lingua del client): dal formato ("%s declines...") al pattern Lua
local function patt(fmt)
  if type(fmt) ~= "string" or fmt == "" then return nil end
  local p = fmt:gsub("([%^%$%(%)%.%[%]%*%+%-%?])", "%%%1")
  p = p:gsub("%%%d?%%?%$?s", "(.-)"):gsub("%%%d?%%?%$?d", "(%%d+)")
  return "^" .. p .. "$"
end
local P_ONLINE = patt(_G.ERR_FRIEND_ONLINE_SS)
local P_RIFIUTA = patt(_G.ERR_DECLINE_GROUP_S)
local P_ALTRO = patt(_G.ERR_ALREADY_IN_GROUP_S)
local function nomeDa(s)
  s = tostring(s or "")
  s = s:match("|Hplayer:([^:|]+)") or s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("[%[%]]", "")
  return (s:gsub("%-.*$", ""))
end

-- ---------------------------------------------------------------- dati dei raid

local function pulisciNome(n)
  n = tostring(n or ""):gsub("%-.*$", "") -- "Nome-Reame" -> "Nome"
  return n
end

-- Nomi su WoW Forever: "Nome Cognome" (roster di gilda, chat, posta, inviti); UnitName da' nome e cognome separati.
-- Due nomi sono la stessa persona se coincidono senza maiuscole e spazi; se uno dei due e' solo il nome
-- (registrato cosi' su Discord), vale per chi ha quel nome.
local function chiaveNome(n) return (pulisciNome(n):gsub("%s+", ""):lower()) end
local function primoNome(n) return ((pulisciNome(n):match("^%s*(%S+)")) or ""):lower() end
local function stessoNome(a, b)
  a, b = tostring(a or ""), tostring(b or "")
  if a == "" or b == "" then return false end
  if chiaveNome(a) == chiaveNome(b) then return true end
  if not pulisciNome(a):find("%s") then return chiaveNome(a) == primoNome(b) end
  if not pulisciNome(b):find("%s") then return chiaveNome(b) == primoNome(a) end
  return false
end
local function nomeIntero(unit)
  local n, cognome = (UnitNameUnmodified or UnitName)(unit)
  if type(n) ~= "string" or (issecretvalue and issecretvalue(n)) then return n end
  if type(cognome) == "string" and cognome ~= "" and not (issecretvalue and issecretvalue(cognome))
    and cognome ~= GetRealmName() and cognome ~= (GetNormalizedRealmName and GetNormalizedRealmName()) then
    return n .. " " .. cognome
  end
  return n
end
-- tabella per nome che trova la persona anche scritta in un altro modo (con o senza cognome, spazi, maiuscole).
-- Le chiavi restano quelle scritte (pairs le vede), la ricerca passa da stessoNome.
local META_NOMI = {
  __index = function(t, n)
    if type(n) ~= "string" then return nil end
    for k, v in next, t do if type(k) == "string" and stessoNome(k, n) then return v end end
    return nil
  end,
  __newindex = function(t, n, v)
    if type(n) == "string" then
      for k in next, t do if type(k) == "string" and stessoNome(k, n) then rawset(t, k, v) return end end
    end
    rawset(t, n, v)
  end,
}
local function tabNomi(t)
  t = t or {}
  if getmetatable(t) ~= META_NOMI then setmetatable(t, META_NOMI) end
  return t
end

local function leggiRiga(riga)
  -- incollata in una casella di WoW la "|" diventa "||" (il gioco la protegge): la riporto com'era; tolgo anche i ``` di Discord
  riga = tostring(riga or ""):gsub("||", "|"):gsub("`", ""):gsub("^%s+", ""):gsub("%s+$", "")
  local p = {}
  for campo in (riga .. "|"):gmatch("([^|]*)|") do p[#p + 1] = campo end
  if p[1] ~= "RE1" or #p < 7 then return nil end
  local r = { id = p[2], raid = p[3], inizio = tonumber(p[4]), ritrovo = tonumber(p[5]), refs = {}, gruppi = {}, panca = {} }
  if not r.id or r.id == "" or not r.inizio then return nil end
  for pezzo in (p[6] or ""):gmatch("[^+,]+") do
    local nome = pezzo:gsub("^%s+", ""):gsub("%s+$", "")
    if nome ~= "" then table.insert(r.refs, nome) end
  end
  r.ref = table.concat(r.refs, ", ")
  local g = 0
  for gruppo in (p[7] .. ";"):gmatch("([^;]*);") do
    g = g + 1
    r.gruppi[g] = {}
    for nome in gruppo:gmatch("[^,]+") do table.insert(r.gruppi[g], nome) end
  end
  for nome in (p[8] or ""):gmatch("[^,]+") do table.insert(r.panca, nome) end
  r.riga = riga
  return r
end

-- nome -> gruppo (panchina = 0)
local function postiDi(r)
  local posti = tabNomi()
  for g, lista in ipairs(r.gruppi) do for _, n in ipairs(lista) do posti[n] = g end end
  for _, n in ipairs(r.panca) do posti[n] = posti[n] or 0 end
  return posti
end

local function ordinati()
  local l = {}
  for _, r in pairs(DB.raids) do l[#l + 1] = r end
  table.sort(l, function(a, b) return a.inizio < b.inizio end)
  return l
end

local function pulisciVecchi()
  local ora = time()
  for id, r in pairs(DB.raids) do if r.inizio + 4 * 3600 < ora then DB.raids[id] = nil end end
  for id in pairs(DB.inv or {}) do if not DB.raids[id] then DB.inv[id] = nil end end
  for id in pairs(DB.contattati or {}) do if not DB.raids[id] then DB.contattati[id] = nil end end
  for ev, t in pairs(DB.annullati or {}) do if t + 14 * 86400 < ora then DB.annullati[ev] = nil end end
end

-- firma di una riga RE1: la stessa che calcola il bot (serve a capire se il raid importato e' vecchio)
local function firma(s)
  local h = 5381
  s = tostring(s or "")
  for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
  return string.format("%.0f", h)
end
local function eventoDi(id) return (tostring(id):match("^(.-)%-%d+$")) or tostring(id) end
local function ponteTs() local p = _G.ERT_Ponte; return type(p) == "table" and tonumber(p.aggiornato) or 0 end
local function hoPonte() return type(_G.ERT_Ponte) == "table" end

-- stato degli inviti per raid: nome -> { s = "invitato" | "rifiutato" | "altro" (in un altro gruppo), t = ora }
local function statoInv(r)
  DB.inv = DB.inv or {}
  DB.inv[r.id] = tabNomi(DB.inv[r.id])
  return DB.inv[r.id]
end

-- ---------------------------------------------------------------- gilda e gruppo

local online, classi, pieni = tabNomi(), tabNomi(), tabNomi() -- pieni: il nome completo del roster, per gli inviti
local function aggiornaOnline()
  local on, cl, pi = {}, {}, {}
  if IsInGuild() then
    for i = 1, GetNumGuildMembers() do
      local nome, _, _, _, _, _, _, _, isOnline, _, classe = GetGuildRosterInfo(i)
      if nome then
        nome = pulisciNome(nome)
        pi[nome] = nome
        if isOnline then on[nome] = true end
        if classe then cl[nome] = classe end
      end
    end
  end
  online, classi, pieni = tabNomi(on), tabNomi(cl), tabNomi(pi)
end

local function coloreClasse(nome, spento)
  if spento then return "|cff6b7480" end
  local c = classi[nome] and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classi[nome]]
  if not c then return "|cffe9e3d2" end
  return ("|cff%02x%02x%02x"):format(math.floor(c.r * 255 + 0.5), math.floor(c.g * 255 + 0.5), math.floor(c.b * 255 + 0.5))
end

local function nelGruppo()
  local n = tabNomi()
  n[nomeIntero("player")] = 0
  if IsInRaid() then
    for i = 1, GetNumGroupMembers() do
      local nome, _, sub = GetRaidRosterInfo(i)
      nome = nome and (nomeIntero("raid" .. i) or nome)
      if nome then n[pulisciNome(nome)] = sub end
    end
  elseif IsInGroup() then
    for i = 1, GetNumSubgroupMembers() do
      local nome = nomeIntero("party" .. i)
      if nome then n[nome] = 1 end
    end
  end
  return n
end

local function invita(nome, r)
  local chi = pieni[nome] or nome -- il nome completo del roster ("Nome Cognome"): col solo nome l'invito puo' non arrivare
  if C_PartyInfo and C_PartyInfo.InviteUnit then C_PartyInfo.InviteUnit(chi) else InviteUnit(chi) end
  invitati[nome] = GetTime()
  ultimoInvito = GetTime()
  if r then statoInv(r)[nome] = { s = "invitato", t = time() } end
end
local function capoOAssistente() return not IsInGroup() or UnitIsGroupLeader("player") or UnitIsGroupAssistant("player") end

local function convertiInRaid()
  if IsInGroup() and not IsInRaid() and UnitIsGroupLeader("player") then
    if C_PartyInfo and C_PartyInfo.ConvertToRaid then C_PartyInfo.ConvertToRaid() else ConvertToRaid() end
  end
end

-- referente del raid: nella riga ci sono i referenti; se non ci sono, chi l'ha importata
local function sonoReferente(r)
  if not r then return false end
  if not r.refs or #r.refs == 0 then return r.mio and true or false end
  local io = nomeIntero("player")
  for _, n in ipairs(r.refs) do if stessoNome(n, io) then return true end end
  return false
end
local function soloReferenti(r)
  if sonoReferente(r) then return true end
  say(r and ("solo i referenti di " .. r.raid .. " (" .. (r.ref ~= "" and r.ref or "chi ha importato la riga") .. ") possono farlo.") or "nessun raid.")
  return false
end

-- officer della gilda (o referente di almeno un raid): puo' fare l'appello
local function sonoOfficer()
  if C_GuildInfo and C_GuildInfo.IsGuildOfficer then
    local ok, v = pcall(C_GuildInfo.IsGuildOfficer)
    if ok and v then return true end
  end
  if CanEditOfficerNote and CanEditOfficerNote() then return true end
  for _, r in pairs(DB and DB.raids or {}) do if sonoReferente(r) and r.refs and #r.refs > 0 then return true end end
  return false
end

-- invita chi e' nel raid (non la panchina), online e non ancora nel gruppo.
-- In automatico un invito solo a testa (se rifiuta non insiste; se rientra in gioco si riprova);
-- col bottone "Invita ora" riprova anche chi non ha risposto, mai chi ha rifiutato (lui puo' scrivere "inv").
local function invitaOnline(r, silenzioso)
  if not r then return 0 end
  if not sonoReferente(r) then
    if not silenzioso then soloReferenti(r) end
    return 0
  end
  if not capoOAssistente() then
    if not silenzioso then say("devi essere capo del gruppo o assistente per invitare.") end
    return 0
  end
  aggiornaOnline()
  local gia, n, posti, st, rifiutati = nelGruppo(), 0, postiDi(r), statoInv(r), 0
  local maxParty = IsInRaid() and 40 or (IsInGroup() and (5 - GetNumGroupMembers()) or 4)
  for nome, g in pairs(posti) do
    local s = st[nome] and st[nome].s
    if g > 0 and online[nome] and not gia[nome] then
      if s == "rifiutato" then rifiutati = rifiutati + 1
      elseif (s == nil or not silenzioso) and (GetTime() - (invitati[nome] or -999)) > 30 and n < maxParty then
        invita(nome, r)
        n = n + 1
      end
    end
  end
  if not silenzioso then
    say((n > 0 and ("inviti mandati: " .. n .. ".") or "nessuno da invitare: chi e' online e' gia' nel gruppo o invitato da poco.")
      .. (rifiutati > 0 and (" Hanno rifiutato: " .. rifiutati .. " (se ti scrivono inv entrano).") or ""))
  end
  return n
end

-- annuncio in chat di gilda (una volta per raid, o di nuovo col bottone)
local function annuncia(r, forza)
  if not r or not IsInGuild() or (r.annunciato and not forza) then return end
  r.annunciato = true
  pcall(Chat, ("RAID %s (%s): inizio a gruppare! Sei in lista e non ti arriva l'invito? Scrivimi inv"):format(r.raid, nomeIntero("player")), "GUILD")
end

-- il referente da' il permesso: annuncio, inviti a chi c'e', poi in automatico fino all'inizio.
-- All'ora d'inizio si spegne tutto l'automatico (inviti, risposte a "inv", sussurri): restano i bottoni a mano.
local function fineInviti(r) return r.inizio end
local function avviaInviti(r)
  DB.auto = r.id
  DB.autoFino = fineInviti(r)
  if IsInGuild() then C_ChatInfo.SendAddonMessage(PREFIX, "I|" .. r.id, "GUILD") end
  annuncia(r)
  say(("inviti ACCESI per %s fino alle %s: chi entra in gioco viene invitato subito, chi scrive inv (in privato o in gilda) anche."):format(r.raid, date("%H:%M", DB.autoFino)))
  invitaOnline(r)
end

-- qualcuno sussurra "inv" (invite, invita, invitami...): se e' nel raid lo invito, anche se prima aveva rifiutato
local function chiestoInvito(msg, mittente)
  if not DB or not attivo() or not opz("inviti") then return end
  if type(msg) ~= "string" or (issecretvalue and issecretvalue(msg)) then return end
  local t = msg:lower():gsub("^%s+", ""):gsub("%s+$", "")
  if #t > 16 or not t:match("^inv%a*[%p%s]") and not t:match("^inv%a*$") then return end
  local nome, ora = pulisciNome(mittente), time()
  for _, r in pairs(DB.raids) do
    local g = postiDi(r)[nome]
    local rit = r.ritrovo or (r.inizio - 1800)
    if g and sonoReferente(r) and ora >= rit - 900 and ora < r.inizio then
      if nelGruppo()[nome] then return end
      if g == 0 then
        pcall(Chat, ("Sei in panchina per %s: se serve ti invito io."):format(r.raid), "WHISPER", nil, nome)
        say(("%s (panchina di %s) ha chiesto l'invito."):format(nome, r.raid))
        return
      end
      if not capoOAssistente() then say(("%s chiede l'invito per %s, ma non sei capo del gruppo o assistente."):format(nome, r.raid)) return end
      if IsInGroup() and not IsInRaid() and GetNumGroupMembers() >= 5 then
        convertiInRaid()
        C_Timer.After(1, function() invita(nome, r) end)
      else
        invita(nome, r)
      end
      say(("%s ha scritto inv: invitato a %s."):format(nome, r.raid))
      return
    end
  end
end

-- messaggi di sistema: chi entra in gioco (invito subito), chi rifiuta, chi e' gia' in un altro gruppo
local function messaggioSistema(t)
  if not DB or not attivo() or type(t) ~= "string" or (issecretvalue and issecretvalue(t)) then return end
  local rifiuta = P_RIFIUTA and t:match(P_RIFIUTA)
  local altro = not rifiuta and P_ALTRO and t:match(P_ALTRO)
  if rifiuta or altro then
    local nome = nomeDa(rifiuta or altro)
    for id, st in pairs(DB.inv or {}) do
      local r = DB.raids[id]
      st = tabNomi(st)
      if r and st[nome] and st[nome].s == "invitato" then
        st[nome] = { s = rifiuta and "rifiutato" or "altro", t = time() }
        if altro and time() < r.inizio then
          pcall(Chat, ("Sei nel raid %s: esci dal gruppo e scrivimi inv per l'invito."):format(r.raid), "WHISPER", nil, nome)
        end
      end
    end
    return
  end
  local r = DB.auto and DB.raids[DB.auto]
  if not r or not sonoReferente(r) or time() >= (DB.autoFino or r.inizio) then return end
  local entra = P_ONLINE and t:match(P_ONLINE)
  local nome = entra and nomeDa(entra) or (t:find("online") and nomeDa(t:match("|Hplayer:([^:|]+)")))
  if not nome or nome == "" or (postiDi(r)[nome] or 0) == 0 then return end
  local st = statoInv(r)
  if st[nome] and st[nome].s == "rifiutato" then return end
  st[nome] = nil
  online[nome] = true
  C_Timer.After(1, function()
    if capoOAssistente() and not nelGruppo()[nome] then invita(nome, r) end
  end)
end

-- sposta ognuno nel gruppo deciso nella pagina di composizione
-- sposta ognuno nel gruppo deciso nella pagina di composizione.
-- soli: solo questi nomi (chi e' appena entrato), gli altri restano dove sono; silenzioso: niente messaggi in chat.
local function sistemaGruppi(r, silenzioso, soli)
  if not r then return end
  if not silenzioso and not soloReferenti(r) then return end
  if not IsInRaid() then if not silenzioso then say("serve essere in raid.") end return end
  if not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") then if not silenzioso then say("devi essere capo raid o assistente.") end return end
  if InCombatLockdown() then if not silenzioso then say("non in combattimento.") end return end
  local posti, giri, fermi = postiDi(r), 0, tabNomi()
  local scelti = soli and tabNomi() or nil
  if soli then for _, n in ipairs(soli) do scelti[n] = true end end
  local function passo()
    giri = giri + 1
    if InCombatLockdown() then return end
    local membri, conta = {}, {}
    for i = 1, GetNumGroupMembers() do
      local nome, _, sub = GetRaidRosterInfo(i)
      nome = nome and (nomeIntero("raid" .. i) or nome)
      if nome then
        membri[#membri + 1] = { i = i, nome = pulisciNome(nome), sub = sub }
        conta[sub] = (conta[sub] or 0) + 1
      end
    end
    local mosso, bloccati = false, 0
    for _, m in ipairs(membri) do
      local voglio = posti[m.nome]
      if voglio and voglio > 0 and voglio ~= m.sub and not fermi[m.nome] and (not scelti or scelti[m.nome]) then
        if (conta[voglio] or 0) < 5 then
          SetRaidSubgroup(m.i, voglio); mosso = true
        else
          -- gruppo pieno: scambio con qualcuno che li' non dovrebbe stare
          for _, altro in ipairs(membri) do
            if altro.sub == voglio and posti[altro.nome] ~= voglio then SwapRaidSubgroup(m.i, altro.i); mosso = true break end
          end
          if not mosso then fermi[m.nome] = true; bloccati = bloccati + 1 end
        end
        if mosso then break end
      end
    end
    if mosso and giri < 60 then C_Timer.After(0.3, passo)
    elseif not silenzioso then
      if bloccati > 0 or mosso then say("non sono riuscito a sistemare tutti (gruppi pieni di gente che deve starci): controlla a mano.")
      else say("gruppi sistemati.") end
    end
  end
  passo()
end

-- appena qualcuno entra nel raid lo metto nel suo gruppo (solo i nuovi: chi hai spostato a mano resta dove l'hai messo).
-- Vale per il raid degli inviti automatici, o per un raid di cui sei referente dal ritrovo (meno 30 minuti) a 3 ore dopo l'inizio.
local visti -- nomi gia' nel raid all'ultimo controllo (nil = raid appena formato: sistemo tutti)
local function raidDaSistemare()
  local r = DB.auto and DB.raids[DB.auto]
  if r then return r end
  local ora = time()
  for _, x in pairs(DB.raids) do
    local rit = x.ritrovo or (x.inizio - 1800)
    if sonoReferente(x) and ora >= rit - 1800 and ora < x.inizio + 3 * 3600 then return x end
  end
end
local function sistemaNuovi()
  if not IsInRaid() then visti = nil return end
  if InCombatLockdown() or not (UnitIsGroupLeader("player") or UnitIsGroupAssistant("player")) then return end
  local r = raidDaSistemare()
  if not r then return end
  local adesso, nuovi = tabNomi(), {}
  for i = 1, GetNumGroupMembers() do
    local nome = nomeIntero("raid" .. i)
    if nome then
      nome = pulisciNome(nome)
      adesso[nome] = true
      if visti and not visti[nome] then nuovi[#nuovi + 1] = nome end
    end
  end
  local primaVolta = visti == nil
  visti = adesso
  if primaVolta then sistemaGruppi(r, true) elseif #nuovi > 0 then sistemaGruppi(r, true, nuovi) end
end
local attesaSistema = false
local function sistemaPresto()
  if attesaSistema then return end
  attesaSistema = true
  C_Timer.After(1, function() attesaSistema = false; sistemaNuovi() end)
end

-- ---------------------------------------------------------------- grafica
-- Stile piatto e scuro (sul modello degli addon moderni tipo ElvUI e Details):
-- pannelli quasi neri, bordo sottile, oro Ethereum per titoli e azioni principali,
-- verde acqua per "acceso", nomi nei colori di classe.

local TMPL = BackdropTemplateMixin and "BackdropTemplate" or nil
local ORO = { 1, 0.82, 0 }
local ACQUA = { 0.05, 0.82, 0.62 }
local function pannello(parent, r, g, b, a, bordo)
  local p = CreateFrame("Frame", nil, parent, TMPL)
  p:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  p:SetBackdropColor(r or 0.05, g or 0.06, b or 0.08, a or 0.95)
  local c = bordo or { 0.17, 0.2, 0.26 }
  p:SetBackdropBorderColor(c[1], c[2], c[3], 1)
  return p
end
local function testo(parent, font, x, y, larg, punto)
  local t = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlightSmall")
  t:SetPoint(punto or "TOPLEFT", x or 0, y or 0)
  t:SetJustifyH("LEFT")
  if larg then t:SetWidth(larg) end
  return t
end
local function bottonePiatto(parent, etichetta, larg, alto, principale, fn)
  local b = CreateFrame("Button", nil, parent, TMPL)
  b:SetSize(larg, alto or 24)
  b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  b.principale = principale
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  b.t:SetPoint("CENTER"); b.t:SetText(etichetta)
  function b:Colora(sopra)
    if not self:IsEnabled() then
      self:SetBackdropColor(0.1, 0.1, 0.12, 1); self:SetBackdropBorderColor(0.2, 0.2, 0.24, 1); self.t:SetTextColor(0.4, 0.4, 0.45)
    elseif self.principale then
      self:SetBackdropColor(ORO[1], ORO[2], ORO[3], sopra and 1 or 0.88); self:SetBackdropBorderColor(1, 0.9, 0.4, 1); self.t:SetTextColor(0.1, 0.08, 0)
    else
      self:SetBackdropColor(0.12, 0.14, 0.18, 1)
      self:SetBackdropBorderColor(sopra and ORO[1] or 0.25, sopra and ORO[2] or 0.28, sopra and ORO[3] or 0.34, 1)
      self.t:SetTextColor(0.92, 0.9, 0.85)
    end
  end
  b:SetScript("OnEnter", function(self) self:Colora(true) end)
  b:SetScript("OnLeave", function(self) self:Colora(false) end)
  b:SetScript("OnEnable", function(self) self:Colora(false) end)
  b:SetScript("OnDisable", function(self) self:Colora(false) end)
  b:SetScript("OnClick", fn)
  b:Colora(false)
  return b
end
-- interruttore a slitta ON/OFF
local function interruttore(parent, acceso, fn)
  local s = CreateFrame("Button", nil, parent, TMPL)
  s:SetSize(58, 22)
  s:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  s.pallino = s:CreateTexture(nil, "OVERLAY"); s.pallino:SetSize(18, 18); s.pallino:SetColorTexture(1, 1, 1, 1)
  s.t = s:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  function s:Aggiorna()
    local on = acceso()
    local spento = not self:IsEnabled()
    self:SetBackdropColor(on and ACQUA[1] * 0.6 or 0.12, on and ACQUA[2] * 0.6 or 0.13, on and ACQUA[3] * 0.6 or 0.16, spento and 0.4 or 1)
    self:SetBackdropBorderColor(on and ACQUA[1] or 0.25, on and ACQUA[2] or 0.28, on and ACQUA[3] or 0.34, 1)
    self.pallino:ClearAllPoints(); self.pallino:SetPoint(on and "RIGHT" or "LEFT", on and -2 or 2, 0)
    self.t:ClearAllPoints(); self.t:SetPoint(on and "LEFT" or "RIGHT", on and 8 or -8, 0)
    self.t:SetText(on and "ON" or "OFF")
    self.t:SetTextColor(1, 1, 1, spento and 0.4 or 1)
  end
  s:SetScript("OnClick", function(self) fn(); self:Aggiorna() end)
  return s
end
local ICONA_SI = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14|t"
local ICONA_NO = "|TInterface\\RaidFrame\\ReadyCheck-NotReady:14|t"
local ICONA_ATTESA = "|TInterface\\RaidFrame\\ReadyCheck-Waiting:14|t"
local ICONA_ON = "|TInterface\\COMMON\\Indicator-Green:12|t"
local ICONA_OFF = "|TInterface\\COMMON\\Indicator-Gray:12|t"

-- ---------------------------------------------------------------- avvisi

-- al login gli avvisi aspettano qualche secondo (il gioco deve finire di caricare)
local codaAvvisi, avvisiPronti = {}, false
local function avvisa(t)
  if not avvisiPronti then codaAvvisi[#codaAvvisi + 1] = t return end
  RaidNotice_AddMessage(RaidWarningFrame, t, ChatTypeInfo["RAID_WARNING"])
  suono(SOUNDKIT and SOUNDKIT.RAID_WARNING or 8959)
  if FlashClientIcon then FlashClientIcon() end
  say(t)
end

local function controllaAvvisi()
  if not attivo() or not opz("avvisi") then return end
  local ora, io = time(), nomeIntero("player")
  for _, r in pairs(DB.raids) do
    local posto = postiDi(r)[io]
    local rit = r.ritrovo or r.inizio
    r.avvisi = r.avvisi or {}
    if posto and ora < r.inizio + 3600 then
      local chi = (r.ref and r.ref ~= "") and ((#r.refs > 1 and " Referenti: " or " Referente: ") .. r.ref .. ".") or ""
      local dove = posto == 0 and " (sei in panchina)" or ""
      if not r.avvisi.pre and ora >= rit - 15 * 60 and ora < rit then
        r.avvisi.pre = true
        avvisa(("Tra 15 minuti si gruppa per %s%s.%s"):format(r.raid, dove, chi))
      end
      if not r.avvisi.ora and ora >= rit then
        r.avvisi.ora = true
        avvisa(("E' ora di gruppare per %s%s!%s"):format(r.raid, dove, chi))
      end
    end
  end
end

-- ---------------------------------------------------------------- popup (inviti e appello)

local function popupBase(icona, alto)
  local p = pannello(UIParent, 0.04, 0.05, 0.07, 0.97, ORO)
  p:SetSize(390, alto or 170); p:SetPoint("TOP", 0, -140); p:SetFrameStrata("DIALOG"); p:Hide()
  p:EnableMouse(true); p:SetMovable(true); p:RegisterForDrag("LeftButton")
  p:SetScript("OnDragStart", p.StartMoving); p:SetScript("OnDragStop", p.StopMovingOrSizing)
  local ic = p:CreateTexture(nil, "ARTWORK"); ic:SetSize(48, 48); ic:SetPoint("TOPLEFT", 16, -16); ic:SetTexture(icona)
  p.titolo = testo(p, "GameFontNormalLarge", 76, -16, 300)
  p.sotto = testo(p, "GameFontHighlight", 76, -40, 300)
  p.info = testo(p, "GameFontDisableSmall", 76, -62, 300)
  return p
end

local popInviti = popupBase("Interface\\Icons\\Ability_Warrior_RallyingCry")
popInviti.si = bottonePiatto(popInviti, "Avvia inviti", 160, 30, true, function()
  local r = popInviti.raid; popInviti:Hide()
  if r then avviaInviti(r) end
end)
popInviti.si:SetPoint("BOTTOMLEFT", 16, 16)
popInviti.no = bottonePiatto(popInviti, "Non ora", 120, 30, false, function() popInviti:Hide() say("ok: puoi avviarli quando vuoi da /ert.") end)
popInviti.no:SetPoint("BOTTOMRIGHT", -16, 16)

local function mostraPopupInviti(r)
  popInviti.raid = r
  aggiornaOnline()
  local tot, on = 0, 0
  for nome, g in pairs(postiDi(r)) do if g > 0 then tot = tot + 1; if online[nome] then on = on + 1 end end end
  popInviti.titolo:SetText(time() >= r.inizio and "Il raid e' gia' iniziato!" or "E' ora di gruppare!")
  popInviti.sotto:SetText(("%s · inizio alle %s"):format(r.raid, date("%H:%M", r.inizio)))
  popInviti.info:SetText(("Online adesso: %d su %d. Annuncio in gilda, invito chi c'e' (se rifiuta non insisto), chi entra in gioco fino alle %s e chi scrive inv."):format(on, tot, date("%H:%M", fineInviti(r))))
  popInviti:Show()
  suono(SOUNDKIT and SOUNDKIT.READY_CHECK or 8960)
  if FlashClientIcon then FlashClientIcon() end
end

-- popup dell'appello (per tutti i giocatori della gilda con ERT)
local popAppello = popupBase("Interface\\Icons\\INV_Misc_Note_01", 160)
local function rispondi(si)
  local a = popAppello.appello; popAppello:Hide()
  if not a then return end
  DB.risposte = DB.risposte or {}
  DB.risposte[a.req] = si and "si" or "no"
  C_ChatInfo.SendAddonMessage(PREFIX, "R|" .. a.req .. "|" .. (si and "si" or "no"), "WHISPER", a.da)
  say(si and ("segnato presente a " .. a.nome .. ".") or ("segnato assente a " .. a.nome .. "."))
end
popAppello.si = bottonePiatto(popAppello, "Ci sono", 150, 30, true, function() rispondi(true) end)
popAppello.si:SetPoint("BOTTOMLEFT", 16, 16)
popAppello.no = bottonePiatto(popAppello, "Non ci sono", 150, 30, false, function() rispondi(false) end)
popAppello.no:SetPoint("BOTTOMRIGHT", -16, 16)

local function mostraAppello(a)
  if not attivo() then return end
  popAppello.appello = a
  popAppello.titolo:SetText("Appello raid")
  popAppello.sotto:SetText(("%s · %s"):format(a.nome, a.inizio and a.inizio > 0 and date("%d/%m alle %H:%M", a.inizio) or ""))
  popAppello.info:SetText(("Te lo chiede %s. Rispondi e ti segno io su Discord."):format(a.da))
  popAppello:Show()
  suono(SOUNDKIT and SOUNDKIT.READY_CHECK or 8960)
  if FlashClientIcon then FlashClientIcon() end
end

-- ---------------------------------------------------------------- messaggi tra addon (gilda)

-- ---------------------------------------------------------------- raid aggiornati, non importati, annullati
-- Il bot non puo' parlare col gioco: le novita' arrivano dal proprio ERT-Ponte (al /reload) oppure
-- dagli ERT della gilda che hanno dati piu' freschi (messaggi V, L, X qui sotto).
local function avvisoUnaVolta(chiave, valore, testoAvviso)
  DB.avvisati = DB.avvisati or {}
  if DB.avvisati[chiave] == valore then return end
  DB.avvisati[chiave] = valore
  avvisa(testoAvviso)
end
local function comeAggiornare()
  return hoPonte() and "premi Sincronizza ora in ERT-Ponte (menu Start) e poi /reload, oppure incolla in /ert la stringa nuova del bot."
    or "incolla in /ert la stringa che ti ha mandato il bot su Discord (o installa ERT-Ponte: /raid ponte)."
end
local function viaDaERT(id)
  local r = DB.raids[id]
  DB.raids[id] = nil
  if DB.inv then DB.inv[id] = nil end
  if DB.auto == id then DB.auto = nil end
  if r and popInviti.raid == r then popInviti:Hide() end
  return r
end
-- tutto l'evento annullato su Discord (/raid cancella): via da ERT, niente popup ne' inviti; non torna piu'
local function annullaEvento(ev)
  DB.annullati = DB.annullati or {}
  DB.annullati[ev] = DB.annullati[ev] or time()
  for id in pairs(DB.raids) do
    if eventoDi(id) == ev then
      local r = viaDaERT(id)
      if r then avvisa(("%s del %s e' stato ANNULLATO su Discord: tolto da ERT, niente popup ne' inviti."):format(r.raid, date("%d/%m", r.inizio))) end
    end
  end
end
-- un solo raid del giorno tolto su Discord
local function toltoRaid(id)
  local r = viaDaERT(id)
  if r then avvisa(("%s del %s e' stato tolto su Discord: tolto anche da ERT."):format(r.raid, date("%d/%m", r.inizio))) end
end
-- una versione arrivata dal bot: x = { id, nome, refs ("A+B"), v (firma), ts (inizio) }
local function controllaVersione(x)
  if not x.id or (DB.annullati and DB.annullati[eventoDi(x.id)]) then return end
  local io, mio = nomeIntero("player"), false
  if x.refs and x.refs ~= "" then
    for n in x.refs:gmatch("[^+]+") do if stessoNome(n, io) then mio = true end end
  else
    -- senza referenti gli inviti li fa chi ha pubblicato i gruppi (lo sa solo il suo ERT-Ponte: pub)
    mio = x.pub == true or x.pub == 1
  end
  if not mio or (tonumber(x.ts) or 0) + 4 * 3600 < time() then return end
  local r = DB.raids[x.id]
  if not r then
    avvisoUnaVolta(x.id, x.v, ("%s del %s: sei referente ma non e' in ERT. Per aggiungerlo %s"):format(x.nome or "Un raid", date("%d/%m alle %H:%M", tonumber(x.ts) or 0), comeAggiornare()))
  elseif firma(r.riga) ~= x.v then
    avvisoUnaVolta(x.id, x.v, ("%s e' cambiato su Discord (gruppi o orari). Per aggiornarlo %s"):format(r.raid, comeAggiornare()))
  end
end
-- passo agli ERT della gilda le versioni che conosco (al login e quando qualcuno chiede)
local ultimeVersioni = -999
local function mandaVersioni()
  local p = _G.ERT_Ponte
  if not IsInGuild() or type(p) ~= "table" or type(p.tutti) ~= "table" or GetTime() - ultimeVersioni < 60 then return end
  ultimeVersioni = GetTime()
  local agg, msgs, eventi = ponteTs(), {}, {}
  for _, x in ipairs(p.tutti) do
    if type(x) == "table" and x.id and (tonumber(x.ts) or 0) + 4 * 3600 > time() then
      msgs[#msgs + 1] = ("V|%s|%s|%d|%d|%s|%s"):format(x.id, x.v or "", agg, tonumber(x.ts) or 0, x.refs or "", tostring(x.nome or ""):gsub("|", ""):sub(1, 60))
      eventi[x.ev or eventoDi(x.id)] = eventi[x.ev or eventoDi(x.id)] or {}
      table.insert(eventi[x.ev or eventoDi(x.id)], tostring(x.id):match("%-(%d+)$") or "0")
    end
  end
  for ev, l in pairs(eventi) do msgs[#msgs + 1] = ("L|%s|%d|%s"):format(ev, agg, table.concat(l, ",")) end
  local ann = type(p.annullati) == "table" and p.annullati or {}
  for i = #ann, math.max(1, #ann - 5), -1 do msgs[#msgs + 1] = ("X|%s|%d"):format(tostring(ann[i]), agg) end
  for i, m in ipairs(msgs) do C_Timer.After(i * 0.4, function() C_ChatInfo.SendAddonMessage(PREFIX, m, "GUILD") end) end
end

local inArrivo = {}
local function manda(r)
  if not IsInGuild() or not r.riga then return end
  local riga, pezzi = r.riga, {}
  for i = 1, #riga, 200 do pezzi[#pezzi + 1] = riga:sub(i, i + 199) end
  for i, pezzo in ipairs(pezzi) do
    C_ChatInfo.SendAddonMessage(PREFIX, "D|" .. r.id .. "|" .. i .. "|" .. #pezzi .. "|" .. pezzo, "GUILD")
  end
  r.mandato = time()
end

local aggiorna -- la finestra (sotto)
local function riceviRaid(testoMsg, mittente)
  local id, i, n, pezzo = testoMsg:match("^D|([^|]+)|(%d+)|(%d+)|(.*)$")
  if not id then return end
  i, n = tonumber(i), tonumber(n)
  local buf = inArrivo[id] or { n = n, parti = {} }
  inArrivo[id] = buf
  buf.parti[i] = pezzo
  for k = 1, n do if not buf.parti[k] then return end end
  inArrivo[id] = nil
  local r = leggiRiga(table.concat(buf.parti))
  if not r or (DB.annullati and DB.annullati[eventoDi(r.id)]) then return end
  local prima = DB.raids[r.id]
  r.da = pulisciNome(mittente)
  r.avvisi = prima and prima.avvisi or {}
  r.mio = prima and prima.mio
  if prima then r.daPonte, r.invDa, r.annunciato = prima.daPonte, prima.invDa, prima.annunciato end
  DB.raids[r.id] = r
  local io = nomeIntero("player")
  if attivo() and postiDi(r)[io] and not (prima and prima.riga == r.riga) then
    say(("sei nel raid |cffffd000%s|r del %s: ritrovo alle %s."):format(r.raid, date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio)))
  end
end

local function ricevi(testoMsg, mittente)
  local io = nomeIntero("player")
  mittente = pulisciNome(mittente)
  local tipo = testoMsg:sub(1, 2)
  if tipo == "D|" then riceviRaid(testoMsg, mittente)
  elseif tipo == "A|" then
    local req, chiave, nome, inizio = testoMsg:match("^A|([^|]+)|([^|]*)|([^|]*)|(%d*)$")
    if req and not stessoNome(mittente, io) and not (DB.risposte and DB.risposte[req]) then
      mostraAppello({ req = req, chiave = chiave, nome = nome, inizio = tonumber(inizio), da = mittente })
    end
  elseif tipo == "Q|" then
    -- un ERT appena entrato chiede le novita': risponde chi ha ERT-Ponte (con un piccolo ritardo a caso)
    if not stessoNome(mittente, io) and hoPonte() then C_Timer.After(1 + math.random() * 4, mandaVersioni) end
  elseif tipo == "V|" then
    local id, v, agg, ini, refs, nome = testoMsg:match("^V|([^|]+)|([^|]*)|(%d+)|(%d+)|([^|]*)|(.*)$")
    if id and not stessoNome(mittente, io) and tonumber(agg) > ponteTs() then controllaVersione({ id = id, v = v, ts = tonumber(ini), refs = refs, nome = nome }) end
  elseif tipo == "L|" then
    -- elenco dei raid ancora vivi di un evento: quelli che ho e non ci sono piu' sono stati tolti
    local ev, agg, lista = testoMsg:match("^L|([^|]+)|(%d+)|(.*)$")
    if ev and not stessoNome(mittente, io) and tonumber(agg) > ponteTs() then
      local ci = {}
      for k in lista:gmatch("%d+") do ci[ev .. "-" .. k] = true end
      for id in pairs(DB.raids) do if eventoDi(id) == ev and not ci[id] then toltoRaid(id) end end
    end
  elseif tipo == "X|" then
    local ev = testoMsg:match("^X|([^|]+)|")
    if ev and not stessoNome(mittente, io) then annullaEvento(ev) end
  elseif tipo == "I|" then
    -- un altro referente ha gia' avviato gli inviti di questo raid: niente popup ne' inviti doppi
    local id = testoMsg:match("^I|(.+)$")
    local r = id and DB.raids[id]
    if r and not stessoNome(mittente, io) then
      r.invDa = mittente
      if popInviti.raid == r and popInviti:IsShown() then popInviti:Hide() end
      if sonoReferente(r) and DB.auto ~= id then say(("inviti di %s avviati da %s."):format(r.raid, mittente)) end
    end
  elseif tipo == "R|" then
    local req, risp = testoMsg:match("^R|([^|]+)|(%a+)$")
    local a = DB.appello
    if req and a and a.req == req and not a.chiuso then
      a.risposte[mittente] = risp == "si" and "si" or "no"
    end
  end
end

-- ---------------------------------------------------------------- finestra principale

local f = pannello(UIParent)
f:SetSize(540, 640); f:SetPoint("CENTER"); f:SetFrameStrata("HIGH")
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
f:Hide()
_G.ERTFrame = f
tinsert(UISpecialFrames, "ERTFrame")

local barra = pannello(f, 0.08, 0.09, 0.12, 1)
barra:SetPoint("TOPLEFT", 1, -1); barra:SetPoint("TOPRIGHT", -1, -1); barra:SetHeight(32)
local logo = barra:CreateTexture(nil, "ARTWORK"); logo:SetSize(22, 22); logo:SetPoint("LEFT", 8, 0); logo:SetTexture("Interface\\Icons\\Ability_Warrior_RallyingCry")
local titolo = testo(barra, "GameFontNormalLarge", 38, 0, nil, "LEFT"); titolo:SetText("ERT")
local sottotitolo = testo(barra, "GameFontDisableSmall", 80, -1, nil, "LEFT"); sottotitolo:SetText("Ethereum Raid Tools")
local statoTesta = testo(barra, "GameFontNormalSmall", -40, 0, nil, "RIGHT"); statoTesta:SetJustifyH("RIGHT")
local chiudi = bottonePiatto(barra, "x", 24, 24, false, function() f:Hide() end); chiudi:SetPoint("RIGHT", -4, 0)

-- schede
local schede, pagine, schedaAttiva = {}, {}, "raid"
local function mostraScheda(nome)
  schedaAttiva = nome
  for k, p in pairs(pagine) do p:SetShown(k == nome) end
  for k, b in pairs(schede) do
    b.riga:SetShown(k == nome)
    b.t:SetTextColor(k == nome and ORO[1] or 0.6, k == nome and ORO[2] or 0.62, k == nome and ORO[3] or 0.66)
  end
  if aggiorna then aggiorna() end
end
local function scheda(nome, etichetta, x)
  local b = CreateFrame("Button", nil, f)
  b:SetSize(120, 28); b:SetPoint("TOPLEFT", x, -36)
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontNormal"); b.t:SetPoint("CENTER"); b.t:SetText(etichetta)
  b.riga = b:CreateTexture(nil, "OVERLAY"); b.riga:SetColorTexture(ORO[1], ORO[2], ORO[3], 1); b.riga:SetHeight(2)
  b.riga:SetPoint("BOTTOMLEFT", 8, 0); b.riga:SetPoint("BOTTOMRIGHT", -8, 0)
  b:SetScript("OnClick", function() mostraScheda(nome) end)
  schede[nome] = b
  local p = CreateFrame("Frame", nil, f)
  p:SetPoint("TOPLEFT", 0, -66); p:SetPoint("BOTTOMRIGHT", 0, 0)
  pagine[nome] = p
  return p
end
local pRaid = scheda("raid", "Raid", 8)
local pPres = scheda("presenze", "Presenze", 128)
local pOpz = scheda("opzioni", "Opzioni", 248)
local pEss = scheda("essentials", "Essentials", 368)
local separatore = f:CreateTexture(nil, "ARTWORK"); separatore:SetColorTexture(0.17, 0.2, 0.26, 1); separatore:SetHeight(1)
separatore:SetPoint("TOPLEFT", 1, -65); separatore:SetPoint("TOPRIGHT", -1, -65)

local function corrente()
  local l = ordinati()
  if raidAttivo and DB.raids[raidAttivo] then return DB.raids[raidAttivo], l end
  raidAttivo = l[1] and l[1].id
  return l[1], l
end

-- ---------- scheda Raid
local boxImp = pannello(pRaid, 0.03, 0.035, 0.05, 1)
boxImp:SetPoint("TOPLEFT", 12, -10); boxImp:SetSize(420, 26)
local campo = CreateFrame("EditBox", nil, boxImp)
campo:SetPoint("TOPLEFT", 6, -4); campo:SetPoint("BOTTOMRIGHT", -6, 4)
campo:SetFontObject("GameFontHighlightSmall"); campo:SetAutoFocus(false); campo:SetMaxLetters(3000)
campo:SetScript("OnEscapePressed", campo.ClearFocus)
local suggerimento = testo(boxImp, "GameFontDisableSmall", 8, 0, 400, "LEFT"); suggerimento:SetText("Incolla qui la stringa che il bot ti ha mandato su Discord")
campo:SetScript("OnTextChanged", function(self) suggerimento:SetShown(self:GetText() == "") end)
local bImporta = bottonePiatto(pRaid, "Importa", 84, 26, true, function()
  local r = leggiRiga(campo:GetText())
  if not r then say("stringa non valida: copiala di nuovo dal messaggio del bot.") return end
  if DB.annullati and DB.annullati[eventoDi(r.id)] then say("questo raid e' stato annullato su Discord: non lo importo.") return end
  local prima = DB.raids[r.id]
  r.avvisi = prima and prima.avvisi or {}
  r.mio = true
  if prima then r.invDa, r.annunciato = prima.invDa, prima.annunciato end
  DB.raids[r.id] = r
  raidAttivo = r.id
  campo:SetText(""); campo:ClearFocus()
  manda(r)
  say(("importato %s: all'ora del ritrovo ti chiedo se far partire gli inviti."):format(r.raid))
  aggiorna()
end)
bImporta:SetPoint("TOPRIGHT", -12, -10)

local bPrima = bottonePiatto(pRaid, "<", 26, 26, false, function()
  local _, l = corrente()
  for k, x in ipairs(l) do if x.id == raidAttivo then raidAttivo = (l[k - 1] or l[#l]).id break end end
  aggiorna()
end)
bPrima:SetPoint("TOPRIGHT", -42, -46)
local bDopo = bottonePiatto(pRaid, ">", 26, 26, false, function()
  local _, l = corrente()
  for k, x in ipairs(l) do if x.id == raidAttivo then raidAttivo = (l[k + 1] or l[1]).id break end end
  aggiorna()
end)
bDopo:SetPoint("TOPRIGHT", -12, -46)
local nomeRaid = testo(pRaid, "GameFontNormalHuge", 14, -46, 420)
local quando = testo(pRaid, "GameFontHighlight", 14, -74, 510)
local chiRef = testo(pRaid, "GameFontDisableSmall", 14, -92, 510)
local stato = testo(pRaid, "GameFontHighlightSmall", 14, -110, 340)
-- due viste: chi manca (durante gli inviti) e i gruppi
local vista -- "manca" o "gruppi"; nil = sceglie ERT (chi manca dal ritrovo in poi)
local bVistaGruppi = bottonePiatto(pRaid, "Gruppi", 76, 22, false, function() vista = "gruppi"; aggiorna() end)
bVistaGruppi:SetPoint("TOPRIGHT", -12, -104)
local bVistaManca = bottonePiatto(pRaid, "Chi manca", 92, 22, false, function() vista = "manca"; aggiorna() end)
bVistaManca:SetPoint("RIGHT", bVistaGruppi, "LEFT", -4, 0)

local rigaAuto = pannello(pRaid, 0.07, 0.08, 0.11, 1)
rigaAuto:SetPoint("TOPLEFT", 12, -130); rigaAuto:SetPoint("TOPRIGHT", -12, -130); rigaAuto:SetHeight(40)
local autoTesto = testo(rigaAuto, "GameFontHighlight", 10, 0, 400, "LEFT")
local swAuto = interruttore(rigaAuto, function() local r = corrente(); return r and DB.auto == r.id end, function()
  local r = corrente()
  if not r or not soloReferenti(r) then return end
  if DB.auto == r.id then DB.auto = nil; say("inviti automatici spenti.") else avviaInviti(r) end
  aggiorna()
end)
swAuto:SetPoint("RIGHT", -10, 0)

local riquadri = {}
for g = 1, 8 do
  local q = pannello(pRaid, 0.07, 0.08, 0.11, 1)
  q:SetSize(252, 80)
  q:SetPoint("TOPLEFT", 12 + ((g - 1) % 2) * 264, -178 - math.floor((g - 1) / 2) * 86)
  q.titolo = testo(q, "GameFontNormalSmall", 6, -4)
  q.titolo:SetText("Gruppo " .. g)
  q.righe = {}
  for i = 1, 5 do q.righe[i] = testo(q, "GameFontHighlightSmall", 8, -5 - i * 13, 238) end
  riquadri[g] = q
end
-- vista "chi manca": un nome per riga, su due colonne, con lo stato dell'invito
local vManca = CreateFrame("Frame", nil, pRaid)
vManca:SetPoint("TOPLEFT", 12, -178); vManca:SetSize(516, 340)
local mancaTesta = testo(vManca, "GameFontNormal", 2, -4, 334)
mancaTesta:SetWordWrap(false)
local mancaRighe, mancaBottoni, mancaNomi = {}, {}, {}
local contattaRaid -- il raid del popup Contatta
local mancanti = {} -- riempito da aggiornaRaid

-- "Contatta su Discord", una persona alla volta: il bot le manda un messaggio privato.
-- Due strade: con ERT-Ponte "Manda e ricarica" (serve un /reload); senza Ponte "Copia per Discord": ERT mostra una
-- stringa da copiare (Ctrl+C) e incollare su Discord nel comando /raid contatta.
-- Si possono mettere in coda piu' persone e mandare tutto insieme.
local function codaDi(r)
  DB.coda = DB.coda or {}
  DB.coda[r.id] = DB.coda[r.id] or {}
  return DB.coda[r.id]
end
local function rigaCoda(r)
  local coda = codaDi(r)
  return ("RM1|%s|%s|%d|%s"):format(tostring(time()) .. math.random(100, 999), r.id, time(), table.concat(coda, ",", 1, math.min(20, #coda)))
end
local function segnaContattati(r)
  DB.contattati = DB.contattati or {}
  DB.contattati[r.id] = tabNomi(DB.contattati[r.id])
  for _, n in ipairs(codaDi(r)) do DB.contattati[r.id][n] = time() end
  DB.coda[r.id] = nil
end
local function mandaCoda(r)
  if #codaDi(r) == 0 then return end
  DB.uscita = DB.uscita or {}
  DB.uscita[#DB.uscita + 1] = rigaCoda(r)
  segnaContattati(r)
  ReloadUI()
end
local popContatta = popupBase("Interface\\Icons\\INV_Letter_15", 250)
-- la stringa da copiare per /raid contatta (selezionata: basta Ctrl+C)
local boxCopia = pannello(popContatta, 0.03, 0.035, 0.05, 1)
boxCopia:SetPoint("BOTTOMLEFT", 16, 56); boxCopia:SetPoint("BOTTOMRIGHT", -16, 56); boxCopia:SetHeight(26)
local campoCopia = CreateFrame("EditBox", nil, boxCopia)
campoCopia:SetPoint("TOPLEFT", 6, -4); campoCopia:SetPoint("BOTTOMRIGHT", -6, 4)
campoCopia:SetFontObject("GameFontHighlightSmall"); campoCopia:SetAutoFocus(false); campoCopia:SetMaxLetters(1000)
campoCopia:SetScript("OnEscapePressed", campoCopia.ClearFocus)
campoCopia:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
boxCopia:Hide()
popContatta.si = bottonePiatto(popContatta, "Manda e ricarica", 130, 30, true, function()
  local r = contattaRaid; popContatta:Hide()
  if r then mandaCoda(r) end
end)
popContatta.si:SetPoint("BOTTOMLEFT", 16, 16)
popContatta.copia = bottonePiatto(popContatta, "Copia per Discord", 130, 30, false, function()
  local r = contattaRaid
  if not r or #codaDi(r) == 0 then return end
  -- nella stringa da copiare uso "~" al posto di "|" (in una casella di WoW la "|" e' un carattere speciale); il bot accetta tutti e due
  campoCopia:SetText("ERT:" .. rigaCoda(r):gsub("|", "~"))
  boxCopia:Show()
  campoCopia:SetFocus(); campoCopia:HighlightText()
  popContatta.info:SetText(("Premi |cffffd000Ctrl+C|r, poi su Discord scrivi |cffffd000/raid contatta|r e incolla nel campo codice: il bot scrive a %s."):format(table.concat(codaDi(r), ", ")))
  segnaContattati(r)
  if aggiorna then aggiorna() end
end)
popContatta.no = bottonePiatto(popContatta, "Aggiungi altri", 110, 30, false, function()
  popContatta:Hide()
  say("in coda: premi Discord su altre persone, poi Manda e ricarica o Copia per Discord.")
  if aggiorna then aggiorna() end
end)
popContatta.no:SetPoint("BOTTOMRIGHT", -16, 16)
local function contatta(n)
  local r = corrente()
  if not r then return end
  if not (sonoReferente(r) or sonoOfficer()) then soloReferenti(r) return end
  local coda = codaDi(r)
  local gia = false
  for _, x in ipairs(coda) do if stessoNome(x, n) then gia = true end end
  if not gia then coda[#coda + 1] = n end
  contattaRaid = r
  boxCopia:Hide(); campoCopia:SetText("")
  -- con ERT-Ponte: Manda e ricarica (principale) e Copia per Discord; senza: solo Copia per Discord (principale)
  local ponte = hoPonte()
  popContatta.si:SetShown(ponte)
  popContatta.copia:ClearAllPoints()
  if ponte then popContatta.copia:SetPoint("LEFT", popContatta.si, "RIGHT", 8, 0) else popContatta.copia:SetPoint("BOTTOMLEFT", 16, 16) end
  popContatta.copia.principale = not ponte; popContatta.copia:Colora(false)
  popContatta.titolo:SetText("Contatta su Discord")
  popContatta.sotto:SetText(#coda == 1 and (n .. " · " .. r.raid) or (("%d persone · %s"):format(#coda, r.raid)))
  popContatta.info:SetText(ponte
    and ("Il bot manda un messaggio privato su Discord a: %s.\nManda e ricarica: serve un /reload. Copia per Discord: incolli la stringa in /raid contatta."):format(table.concat(coda, ", "))
    or ("Il bot manda un messaggio privato su Discord a: %s.\nCopia per Discord: copi una stringa e la incolli su Discord in /raid contatta."):format(table.concat(coda, ", ")))
  popContatta:Show()
end
for i = 1, 30 do
  local x, y = 2 + (i > 15 and 262 or 0), -30 - ((i - 1) % 15) * 19
  mancaRighe[i] = testo(vManca, "GameFontHighlightSmall", x, y, 196)
  mancaRighe[i]:SetWordWrap(false)
  local b = bottonePiatto(vManca, "Discord", 54, 17, false, function() if mancaNomi[i] then contatta(mancaNomi[i]) end end)
  b.t:SetFontObject("GameFontHighlightSmall")
  b:SetPoint("TOPLEFT", x + 200, y + 2)
  b:Hide()
  mancaBottoni[i] = b
end
local mancaAltri = testo(vManca, "GameFontDisableSmall", 2, -320, 510)

local panca = testo(pRaid, "GameFontHighlightSmall", 14, -526, 510)
local legenda = testo(pRaid, "GameFontDisableSmall", 14, -542, 510)
legenda:SetText(ICONA_SI .. " nel gruppo   " .. ICONA_ATTESA .. " invitato   " .. ICONA_NO .. " ha rifiutato   " .. ICONA_ON .. " online   " .. ICONA_OFF .. " offline")
local bInvita = bottonePiatto(pRaid, "Invita ora", 120, 28, true, function() invitaOnline((corrente())) end)
bInvita:SetPoint("BOTTOMLEFT", 12, 12)
local bGruppi = bottonePiatto(pRaid, "Rimetti nei gruppi", 150, 28, false, function() sistemaGruppi((corrente())) end)
bGruppi:SetPoint("LEFT", bInvita, "RIGHT", 6, 0)
local bAnnuncia = bottonePiatto(pRaid, "Annuncio in gilda", 140, 28, false, function()
  local r = corrente()
  if r and soloReferenti(r) then annuncia(r, true); manda(r) end
end)
bAnnuncia:SetPoint("LEFT", bGruppi, "RIGHT", 6, 0)
-- dati nuovi da Discord (ERT-Ponte): il gioco legge i file solo al /reload, non serve chiudere WoW
local bRicaricaRaid = bottonePiatto(pRaid, "Ricarica", 90, 28, false, function() ReloadUI() end)
bRicaricaRaid:SetPoint("LEFT", bAnnuncia, "RIGHT", 6, 0)

local function aggiornaRaid()
  local r, l = corrente()
  local ref = r and sonoReferente(r) and true or false
  bInvita:SetEnabled(ref); bGruppi:SetEnabled(ref); bAnnuncia:SetEnabled(ref); swAuto:SetEnabled(ref)
  bPrima:SetShown(#l > 1); bDopo:SetShown(#l > 1)
  if not r then
    nomeRaid:SetText("Nessun raid in programma")
    quando:SetText("Quando i gruppi vengono pubblicati, il bot manda la stringa ai referenti.")
    chiRef:SetText("Gli altri lo ricevono da soli dall'ERT del referente.")
    stato:SetText(""); panca:SetText(""); autoTesto:SetText("")
    for g = 1, 8 do riquadri[g]:Hide() end
    vManca:Hide(); bVistaManca:Hide(); bVistaGruppi:Hide()
    swAuto:Aggiorna()
    return
  end
  bVistaManca:Show(); bVistaGruppi:Show()
  local rit = r.ritrovo or (r.inizio - 1800)
  local v = vista or ((time() >= rit - 900 and time() < r.inizio + 3 * 3600) and "manca" or "gruppi")
  bVistaManca.principale = v == "manca"; bVistaManca:Colora(false)
  bVistaGruppi.principale = v == "gruppi"; bVistaGruppi:Colora(false)
  aggiornaOnline()
  local gia = nelGruppo()
  local pos = 0
  for k, x in ipairs(l) do if x.id == r.id then pos = k end end
  nomeRaid:SetText(r.raid .. (#l > 1 and ("  |cff9aa3ae" .. pos .. "/" .. #l .. "|r") or ""))
  quando:SetText(("%s     |cffffd000Ritrovo|r %s     |cffffd000Inizio|r %s"):format(date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio - 1800), date("%H:%M", r.inizio)))
  local p = _G.ERT_Ponte
  local daDiscord = (r.daPonte and type(p) == "table" and tonumber(p.aggiornato)) and ("   |cff6b7480dati da Discord delle " .. date("%H:%M", p.aggiornato) .. "|r") or ""
  chiRef:SetText(((r.ref and r.ref ~= "") and ((#r.refs > 1 and "Referenti: " or "Referente: ") .. r.ref) or "Referente: chi ha importato la stringa")
    .. (r.invDa and ("   |cff9aa3aeinviti avviati da " .. r.invDa .. "|r") or "") .. daDiscord)
  local st = DB.inv and DB.inv[r.id] or {}
  local tot, on, dentro, invit, rif = 0, 0, 0, 0, 0
  local function nome(n)
    local s = not gia[n] and st[n] and st[n].s
    local icona = gia[n] and ICONA_SI or s == "rifiutato" and ICONA_NO or (s == "invitato" and online[n]) and ICONA_ATTESA or online[n] and ICONA_ON or ICONA_OFF
    local nota = s == "rifiutato" and "  |cffff6b5arifiutato|r" or s == "altro" and "  |cff9aa3aein un altro gruppo|r"
      or (s == "invitato" and online[n]) and "  |cff9aa3aeinvitato|r" or ""
    return icona .. " " .. coloreClasse(n, not online[n] and not gia[n]) .. n .. "|r" .. nota
  end
  for g = 1, 8 do
    local lista = r.gruppi[g] or {}
    local q = riquadri[g]
    if g <= math.max(1, #r.gruppi) then
      q:SetShown(v == "gruppi")
      for i = 1, 5 do
        local n = lista[i]
        q.righe[i]:SetText(n and nome(n) or "")
        if n then
          tot = tot + 1
          if gia[n] then dentro = dentro + 1
          elseif online[n] then
            on = on + 1
            local s = st[n] and st[n].s
            if s == "invitato" then invit = invit + 1 elseif s == "rifiutato" then rif = rif + 1 end
          end
        end
      end
    else
      q:Hide()
    end
  end
  local pc = {}
  for _, n in ipairs(r.panca) do pc[#pc + 1] = nome(n) end
  panca:SetText(#pc > 0 and ("|cffffd000Panchina|r   " .. table.concat(pc, "   ")) or "")
  local mancano = tot - dentro
  stato:SetText(mancano == 0 and ("|cff40c040Ci sono tutti|r: %d su %d nel gruppo"):format(dentro, tot)
    or ("Nel gruppo |cffffffff%d|r/%d  ·  |cff40c040%d online|r  ·  |cff9aa3ae%d offline|r"):format(dentro, tot, on, mancano - on))

  -- chi manca: un nome per riga (prima chi e' online), con lo stato dell'invito
  wipe(mancanti)
  for _, lista in ipairs(r.gruppi) do for _, n in ipairs(lista) do if not gia[n] then mancanti[#mancanti + 1] = n end end end
  local peso = function(n)
    local s = st[n] and st[n].s
    if not online[n] then return 4 end
    return s == nil and 1 or s == "invitato" and 2 or 3
  end
  table.sort(mancanti, function(a, b) if peso(a) ~= peso(b) then return peso(a) < peso(b) end return a < b end)
  vManca:SetShown(v == "manca")
  local cont = tabNomi(DB.contattati and DB.contattati[r.id] or {})
  local inCoda = tabNomi()
  for _, x in ipairs(DB.coda and DB.coda[r.id] or {}) do inCoda[x] = true end
  mancaTesta:SetText(mancano == 0 and "|cff40c040Ci sono tutti!|r" or ("Mancano |cffffffff%d|r su %d   |cff9aa3ae(%d online: %d invitati, %d hanno rifiutato)|r"):format(mancano, tot, on, invit, rif))
  for i = 1, 30 do
    local n = mancanti[i]
    if n then
      local s = st[n] and st[n].s
      local icona, cosa
      if not online[n] then icona, cosa = ICONA_OFF, "|cff6b7480offline|r"
      elseif s == "rifiutato" then icona, cosa = ICONA_NO, "|cffff6b5aha rifiutato|r"
      elseif s == "invitato" then icona, cosa = ICONA_ATTESA, "|cff9aa3aeinvitato, aspetto|r"
      elseif s == "altro" then icona, cosa = ICONA_ATTESA, "|cff9aa3aein un altro gruppo|r"
      else icona, cosa = ICONA_ON, "|cff40c040online|r" end
      if cont[n] then cosa = cosa .. " |cff6b7480· Discord " .. date("%H:%M", cont[n]) .. "|r" end
      mancaRighe[i]:SetText(icona .. " " .. coloreClasse(n, not online[n]) .. n .. "|r  " .. cosa)
      mancaNomi[i] = n
      mancaBottoni[i].t:SetText(inCoda[n] and "in coda" or "Discord")
      mancaBottoni[i]:Show()
    else
      mancaRighe[i]:SetText("")
      mancaNomi[i] = nil
      mancaBottoni[i]:Hide()
    end
  end
  mancaAltri:SetText(#mancanti > 30 and ("e altri " .. (#mancanti - 30)) or "")
  autoTesto:SetText(ref and ("|cffffd000Inviti automatici|r  |cff9aa3aefino alle " .. date("%H:%M", DB.auto == r.id and DB.autoFino or r.inizio) .. ", e a chi scrive inv|r")
    or "|cff6b7480Inviti automatici: solo per i referenti di questo raid|r")
  swAuto:Aggiorna()
end

-- ---------- scheda Presenze (appello)
local presTitolo = testo(pPres, "GameFontNormalLarge", 14, -12, 510)
presTitolo:SetText("Appello presenze")
local presAiuto = testo(pPres, "GameFontDisableSmall", 14, -34, 510)
presAiuto:SetText("Scegli il raid e chiedi alla gilda chi c'e'. Chi ha ERT risponde da un popup: chi dice si' viene segnato al raid su Discord.")
local selRaid = pannello(pPres, 0.07, 0.08, 0.11, 1)
selRaid:SetPoint("TOPLEFT", 12, -62); selRaid:SetPoint("TOPRIGHT", -12, -62); selRaid:SetHeight(44)
local selNome = testo(selRaid, "GameFontNormal", 44, -8, 420)
local selQuando = testo(selRaid, "GameFontDisableSmall", 44, -26, 420)
local scelto = 1
local function raidPerAppello()
  local l = {}
  local ponte = _G.ERT_Ponte
  local delPonte = {}
  if type(ponte) == "table" and type(ponte.eventi) == "table" then
    for _, e in ipairs(ponte.eventi) do delPonte[e.id] = true end
  end
  -- i raid importati a mano; quelli che il ponte conosce gia' compaiono una volta sola (dal ponte)
  for _, r in ipairs(ordinati()) do
    if not delPonte[(r.id:match("^(.-)%-%d+$") or r.id)] then l[#l + 1] = { chiave = r.id, nome = r.raid, inizio = r.inizio } end
  end
  if type(ponte) == "table" and type(ponte.eventi) == "table" then
    for _, e in ipairs(ponte.eventi) do
      for _, x in ipairs(e.raids or {}) do l[#l + 1] = { chiave = e.id .. ":" .. x.k, nome = x.nome, inizio = x.ts } end
    end
  end
  return l
end
local selPrima = bottonePiatto(selRaid, "<", 26, 26, false, function() scelto = scelto - 1; aggiorna() end)
selPrima:SetPoint("LEFT", 8, 0)
local selDopo = bottonePiatto(selRaid, ">", 26, 26, false, function() scelto = scelto + 1; aggiorna() end)
selDopo:SetPoint("RIGHT", -8, 0)

local bChiedi = bottonePiatto(pPres, "Chiedi presenze alla gilda", 230, 30, true, function()
  local l = raidPerAppello()
  local x = l[scelto]
  if not x then say("non c'e' nessun raid da scegliere.") return end
  if not sonoOfficer() then say("l'appello lo possono fare gli officer e i referenti.") return end
  local req = tostring(time()) .. math.random(100, 999)
  DB.appello = { req = req, chiave = x.chiave, nome = x.nome, inizio = x.inizio, t = time(), risposte = {} }
  C_ChatInfo.SendAddonMessage(PREFIX, ("A|%s|%s|%s|%d"):format(req, x.chiave, (x.nome or ""):gsub("|", ""), x.inizio or 0), "GUILD")
  if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
  say(("appello mandato alla gilda per %s."):format(x.nome))
  aggiorna()
end)
bChiedi:SetPoint("TOPLEFT", 12, -116)
local bAnch = bottonePiatto(pPres, "Ci sono anch'io", 140, 30, false, function()
  local a = DB.appello
  if a and not a.chiuso then a.risposte[nomeIntero("player")] = "si"; aggiorna() end
end)
bAnch:SetPoint("LEFT", bChiedi, "RIGHT", 8, 0)
local presStato = testo(pPres, "GameFontHighlight", 14, -156, 510)
local colonne = {}
for c = 1, 2 do
  colonne[c] = testo(pPres, "GameFontHighlightSmall", 14 + (c - 1) * 262, -178, 250)
  colonne[c]:SetJustifyV("TOP"); colonne[c]:SetHeight(330)
end
local bSalva = bottonePiatto(pPres, "Chiudi appello e salva", 200, 28, true, function()
  local a = DB.appello
  if not a or a.chiuso then return end
  a.chiuso = true
  local si, no = {}, {}
  for n, v in pairs(a.risposte) do if v == "si" then si[#si + 1] = n else no[#no + 1] = n end end
  DB.uscita = DB.uscita or {}
  DB.uscita[#DB.uscita + 1] = ("RC1|%s|%s|%d|%s|%s"):format(a.req, a.chiave, time(), table.concat(si, ","), table.concat(no, ","))
  if type(_G.ERT_Ponte) == "table" then
    say(("appello chiuso: %d presenti, %d assenti. Premi |cffffd000Ricarica e manda a Discord|r (o esci dal gioco): ci pensa ERT-Ponte."):format(#si, #no))
  else
    say(("appello chiuso: %d presenti, %d assenti. Per mandarlo a Discord serve ERT-Ponte sul PC: su Discord scrivi /raid ponte."):format(#si, #no))
  end
  aggiorna()
end)
bSalva:SetPoint("BOTTOMLEFT", 12, 12)
local bRicarica = bottonePiatto(pPres, "Ricarica e manda a Discord", 210, 28, false, function() ReloadUI() end)
bRicarica:SetPoint("LEFT", bSalva, "RIGHT", 6, 0)

local function aggiornaPresenze()
  local l = raidPerAppello()
  if scelto > #l then scelto = 1 elseif scelto < 1 then scelto = #l end
  local x = l[scelto]
  selNome:SetText(x and x.nome or "Nessun raid in programma")
  selQuando:SetText(x and x.inizio and x.inizio > 0 and date("%d/%m alle %H:%M", x.inizio) or "Importa un raid nella scheda Raid (con ERT-Ponte arrivano da soli)")
  selPrima:SetShown(#l > 1); selDopo:SetShown(#l > 1)
  local off = sonoOfficer()
  bChiedi:SetEnabled(off and x ~= nil)
  local a = DB.appello
  bAnch:SetEnabled(a ~= nil and not a.chiuso)
  bSalva:SetEnabled(a ~= nil and not a.chiuso)
  bRicarica:SetEnabled(DB.uscita ~= nil and #DB.uscita > 0)
  if not off then
    presStato:SetText("|cff6b7480L'appello lo possono fare gli officer e i referenti. Quando qualcuno lo fa, ti compare un popup.|r")
    colonne[1]:SetText(""); colonne[2]:SetText("")
    return
  end
  if not a then
    presStato:SetText("Nessun appello in corso.")
    colonne[1]:SetText(""); colonne[2]:SetText("")
    return
  end
  aggiornaOnline()
  local voci, si, no, attesa = {}, 0, 0, 0
  local visti = {}
  for n, v in pairs(a.risposte) do voci[#voci + 1] = { n = n, v = v }; visti[n] = true end
  if not a.chiuso then for n in pairs(online) do if not visti[n] then voci[#voci + 1] = { n = n, v = "attesa" } end end end
  local ordine = { si = 1, no = 2, attesa = 3 }
  table.sort(voci, function(p, q) if ordine[p.v] ~= ordine[q.v] then return ordine[p.v] < ordine[q.v] end return p.n < q.n end)
  local righe = { {}, {} }
  for i, v in ipairs(voci) do
    if v.v == "si" then si = si + 1 elseif v.v == "no" then no = no + 1 else attesa = attesa + 1 end
    if i <= 44 then
      local icona = v.v == "si" and ICONA_SI or v.v == "no" and ICONA_NO or ICONA_ATTESA
      table.insert(righe[i <= 22 and 1 or 2], icona .. " " .. coloreClasse(v.n, v.v == "attesa") .. v.n .. "|r")
    end
  end
  presStato:SetText(("%s%s   |cff40c040%d si'|r   |cffff6b5a%d no|r   |cff9aa3ae%d senza risposta|r"):format(
    a.chiuso and "|cff9aa3aeChiuso|r  " or "|cffffd000In corso|r  ", a.nome, si, no, attesa))
  colonne[1]:SetText(table.concat(righe[1], "\n")); colonne[2]:SetText(table.concat(righe[2], "\n"))
end

-- ---------- scheda Opzioni
local opzTitolo = testo(pOpz, "GameFontNormalLarge", 14, -12, 510); opzTitolo:SetText("Opzioni")
local voci = {
  { k = "enabled", t = "ERT acceso", d = "Spento: niente avvisi, popup e inviti automatici (la finestra resta apribile).",
    get = function() return attivo() end, set = function() DB.enabled = not attivo() end },
  { k = "inviti", t = "Inviti al ritrovo (referenti)", d = "All'ora del ritrovo ti chiedo il permesso, poi annuncio, inviti e risposta a \"inv\".",
    get = function() return opz("inviti") end, set = function() DB.opz.inviti = not opz("inviti"); if not opz("inviti") then DB.auto = nil end end },
  { k = "avvisi", t = "Avvisi di ritrovo", d = "15 minuti prima e all'ora del ritrovo, se sei nel raid.",
    get = function() return opz("avvisi") end, set = function() DB.opz.avvisi = not opz("avvisi") end },
}
local interruttoriOpz = {}
for i, v in ipairs(voci) do
  local r = pannello(pOpz, 0.07, 0.08, 0.11, 1)
  r:SetPoint("TOPLEFT", 12, -40 - (i - 1) * 58); r:SetPoint("TOPRIGHT", -12, -40 - (i - 1) * 58); r:SetHeight(50)
  local t1 = testo(r, "GameFontNormal", 10, -9, 420); t1:SetText(v.t)
  local t2 = testo(r, "GameFontDisableSmall", 10, -27, 420); t2:SetText(v.d)
  local s = interruttore(r, v.get, function() v.set(); if ERT_AggiornaBottone then ERT_AggiornaBottone() end end)
  s:SetPoint("RIGHT", -10, 0)
  interruttoriOpz[#interruttoriOpz + 1] = s
end
local versione = testo(pOpz, "GameFontDisableSmall", 14, -40 - #voci * 58 - 6, 510)
versione:SetText("ERT " .. VERSIONE .. " · /ert apre questa finestra · /ert essentials, /ert invita, /ert gruppi, /ert on, /ert off")
local statoPonte = testo(pOpz, "GameFontHighlightSmall", 14, -40 - #voci * 58 - 26, 510)
-- ERT-Ponte: programma sul PC che porta i raid da Discord (ERT_Dati.lua) e le presenze a Discord
local function testoPonte()
  local p = _G.ERT_Ponte
  if type(p) ~= "table" then
    return "|cff9aa3aeERT-Ponte non collegato.|r Su Discord scrivi |cffffd000/raid ponte|r e apri il file: i raid arrivano da soli in ERT e le presenze dell'appello vanno da sole su Discord."
  end
  local n = type(p.righe) == "table" and #p.righe or 0
  local quando = tonumber(p.aggiornato) and date("%d/%m alle %H:%M", p.aggiornato) or "?"
  return ("|cff0cd29fERT-Ponte collegato|r%s · dati del %s · %d raid da referente. Per i dati nuovi: /reload."):format(
    p.chi and p.chi ~= "" and (" come " .. p.chi) or "", quando, n)
end

-- ---------- scheda Essentials: aure FA della gilda (da ERT-Ponte) e addon obbligatori
local function essentials() local p = _G.ERT_Ponte; return type(p) == "table" and type(p.essentials) == "table" and p.essentials or nil end
local function statoFa(x)
  local mia = DB.fa and DB.fa[x.n]
  if mia == x.v then return "importata" elseif mia then return "aggiornata" end
  return "nuova"
end
local function faDaImportare()
  local l = {}
  local e = essentials()
  for _, x in ipairs(e and e.fa or {}) do if type(x) == "table" and x.n and statoFa(x) ~= "importata" then l[#l + 1] = x end end
  return l
end
-- importa un'aura in ForeverAuras: si apre la sua finestra e si conferma li'; "dopo" serve per farle una dopo l'altra
local function importaFa(x, dopo)
  local api = _G.ForeverAuras or _G.WeakAuras
  if not api or not api.Import then say("ForeverAuras non e' installato o non e' acceso.") return end
  if InCombatLockdown() then say("non in combattimento.") return end
  local ok, _, errore = pcall(api.Import, x.s, nil, function(riuscito)
    if riuscito then
      DB.fa = DB.fa or {}
      DB.fa[x.n] = x.v
      say(("aura |cffffd000%s|r importata in ForeverAuras."):format(x.n))
    end
    aggiorna()
    if dopo and riuscito then C_Timer.After(0.6, dopo) end
  end)
  if not ok or errore then say(("ForeverAuras non accetta l'aura %s: %s"):format(x.n, tostring(errore or "errore"))) end
end

local essTitolo = testo(pEss, "GameFontNormalLarge", 14, -12, 360); essTitolo:SetText("Aure di gilda (ForeverAuras)")
local essAiuto = testo(pEss, "GameFontDisableSmall", 14, -34, 510)
local bImportaNuove = bottonePiatto(pEss, "Importa le nuove", 150, 24, true, function()
  local coda = faDaImportare()
  if #coda == 0 then say("nessuna aura nuova o aggiornata.") return end
  local i = 0
  local function prossima()
    i = i + 1
    if coda[i] then importaFa(coda[i], prossima) end
  end
  prossima()
end)
bImportaNuove:SetPoint("TOPRIGHT", -12, -10)
local righeFa, datiFa, datiAdd = {}, {}, {} -- datiFa[i] / datiAdd[i]: cosa mostra la riga i
for i = 1, 9 do
  local r = pannello(pEss, 0.07, 0.08, 0.11, 1)
  r:SetPoint("TOPLEFT", 12, -56 - (i - 1) * 32); r:SetPoint("TOPRIGHT", -12, -56 - (i - 1) * 32); r:SetHeight(28)
  r.nome = testo(r, "GameFontHighlight", 10, 0, 300, "LEFT"); r.nome:SetWordWrap(false)
  r.stato = testo(r, "GameFontNormalSmall", -112, 0, 110, "RIGHT"); r.stato:SetJustifyH("RIGHT")
  r.b = bottonePiatto(r, "Importa", 92, 22, false, function() if datiFa[i] then importaFa(datiFa[i]) end end)
  r.b:SetPoint("RIGHT", -4, 0)
  righeFa[i] = r
end
local faAltre = testo(pEss, "GameFontDisableSmall", 14, -346, 510)

local addTitolo = testo(pEss, "GameFontNormalLarge", 14, -366, 510); addTitolo:SetText("Addon della gilda")
local addAiuto = testo(pEss, "GameFontDisableSmall", 14, -388, 510)
local righeAdd = {}
local boxLink = pannello(pEss, 0.03, 0.035, 0.05, 1)
boxLink:SetPoint("BOTTOMLEFT", 12, 12); boxLink:SetPoint("BOTTOMRIGHT", -12, 12); boxLink:SetHeight(26)
local campoLink = CreateFrame("EditBox", nil, boxLink)
campoLink:SetPoint("TOPLEFT", 6, -4); campoLink:SetPoint("BOTTOMRIGHT", -6, 4)
campoLink:SetFontObject("GameFontHighlightSmall"); campoLink:SetAutoFocus(false)
campoLink:SetScript("OnEscapePressed", campoLink.ClearFocus)
campoLink:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
local linkAiuto = testo(boxLink, "GameFontDisableSmall", 8, 0, 480, "LEFT"); linkAiuto:SetText("Clicca un addon: qui compare il link CurseForge da copiare (Ctrl+C)")
campoLink:SetScript("OnTextChanged", function(self) linkAiuto:SetShown(self:GetText() == "") end)
for i = 1, 10 do
  local b = CreateFrame("Button", nil, pEss)
  b:SetSize(252, 18)
  b:SetPoint("TOPLEFT", 14 + (i > 5 and 262 or 0), -410 - ((i - 1) % 5) * 20)
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.t:SetPoint("LEFT"); b.t:SetWidth(250); b.t:SetJustifyH("LEFT"); b.t:SetWordWrap(false)
  b:SetScript("OnClick", function(self)
    local x = datiAdd[i]
    if x and x.l and x.l ~= "" then campoLink:SetText(x.l); campoLink:SetFocus(); campoLink:HighlightText()
    else say("per questo addon non c'e' il link: cercalo su CurseForge.") end
  end)
  righeAdd[i] = b
end
local function addonPresente(cartella)
  if not cartella or cartella == "" then return nil end
  if C_AddOns and C_AddOns.DoesAddOnExist then return C_AddOns.DoesAddOnExist(cartella) end
  local fn = (C_AddOns and C_AddOns.GetAddOnInfo) or GetAddOnInfo
  if not fn then return nil end
  local _, _, _, _, motivo = fn(cartella)
  return motivo ~= "MISSING"
end

local function aggiornaEssentials()
  local e = essentials()
  local fa = e and e.fa or {}
  local addons = e and e.addons or {}
  if not hoPonte() then
    essAiuto:SetText("Senza ERT-Ponte le aure non arrivano qui: su Discord scrivi /essentials e copia le stringhe (o installa ERT-Ponte: /raid ponte).")
  elseif #fa == 0 then
    essAiuto:SetText("Gli officer non hanno ancora messo aure. Arrivano da sole con ERT-Ponte (all'avvio o con Sincronizza ora, poi /reload).")
  else
    local n = #faDaImportare()
    essAiuto:SetText(n > 0 and ("|cff40c040%d da importare|r (nuove o aggiornate). Importa apre ForeverAuras: conferma li'."):format(n)
      or "Tutte importate. Quando un officer ne cambia una, qui compare 'aggiornata'.")
  end
  bImportaNuove:SetEnabled(#faDaImportare() > 0)
  for i, r in ipairs(righeFa) do
    local x = fa[i]
    datiFa[i] = type(x) == "table" and x or nil
    r:SetShown(datiFa[i] ~= nil)
    if datiFa[i] then
      local s = statoFa(datiFa[i])
      r.nome:SetText(datiFa[i].n)
      r.stato:SetText(s == "importata" and "|cff6b7480importata|r" or s == "aggiornata" and "|cffffd000aggiornata|r" or "|cff40c040nuova|r")
      r.b.t:SetText(s == "importata" and "Reimporta" or "Importa")
      r.b.principale = s ~= "importata"; r.b:Colora(false)
    end
  end
  faAltre:SetText(#fa > #righeFa and ("e altre %d: su Discord /essentials"):format(#fa - #righeFa) or "")
  local mancano = 0
  for i, b in ipairs(righeAdd) do
    local x = addons[i]
    datiAdd[i] = type(x) == "table" and x or nil
    b:SetShown(datiAdd[i] ~= nil)
    if datiAdd[i] then
      local c = addonPresente(datiAdd[i].c)
      if c == false then mancano = mancano + 1 end
      b.t:SetText((c == true and ICONA_SI or c == false and ICONA_NO or ICONA_ATTESA) .. " " .. datiAdd[i].n .. (c == false and "  |cffff6b5amanca|r" or ""))
    end
  end
  addAiuto:SetText(#addons == 0 and "Gli officer non hanno ancora messo la lista. Su Discord: /essentials."
    or ("Installali e aggiornali con l'app CurseForge.%s%s"):format(mancano > 0 and ("  |cffff6b5aTi mancano: " .. mancano .. "|r") or "",
      #addons > #righeAdd and ("  Altri " .. (#addons - #righeAdd) .. ": /essentials su Discord.") or ""))
  boxLink:SetShown(#addons > 0)
end

aggiorna = function()
  if not f:IsShown() or not DB then return end
  statoTesta:SetText(attivo() and "|cff0cd29facceso|r" or "|cff999999spento|r")
  if schedaAttiva == "raid" then aggiornaRaid()
  elseif schedaAttiva == "presenze" then aggiornaPresenze()
  elseif schedaAttiva == "essentials" then aggiornaEssentials()
  else for _, s in ipairs(interruttoriOpz) do s:Aggiorna() end; statoPonte:SetText(testoPonte()) end
end
f:SetScript("OnShow", function() if IsInGuild() and C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end aggiorna() end)

-- ---------------------------------------------------------------- minimappa, comandi, eventi

local broker, icona
local function minimappaVisibile()
  if DB.opz.minimappa ~= nil then return DB.opz.minimappa ~= false end
  -- con la barra BottoniMinimappa il bottone c'e' gia' li'
  local caricata = (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("BottoniMinimappa")) or (IsAddOnLoaded and IsAddOnLoaded("BottoniMinimappa"))
  return not caricata
end
ERT_MinimappaVisibile = minimappaVisibile
function ERT_AggiornaMinimappa()
  if not icona then return end
  if minimappaVisibile() then icona:Show("ERT") else icona:Hide("ERT") end
end
function ERT_AggiornaBottone()
  if broker then broker.icon = "Interface\\Icons\\Ability_Warrior_RallyingCry" end
  if ERT_BottoneBarra then ERT_BottoneBarra() end
end
-- per la barra BottoniMinimappa: acceso o spento
function ERT_Acceso() return attivo() end

local function accendi(v)
  DB.enabled = v
  if not v then DB.auto = nil end
  say(v and "acceso." or "spento: niente avvisi, popup e inviti automatici.")
  ERT_AggiornaBottone()
  aggiorna()
end

SLASH_ERT1 = "/ert"
SLASH_ERT2 = "/raideth"
SlashCmdList.ERT = function(msg)
  msg = (msg or ""):lower()
  if msg == "on" then accendi(true)
  elseif msg == "off" then accendi(false)
  elseif msg == "toggle" then accendi(not attivo())
  elseif msg:match("^invita") then invitaOnline((corrente()))
  elseif msg:match("^gruppi") then sistemaGruppi((corrente()))
  elseif msg:match("^presenze") then f:Show(); mostraScheda("presenze")
  elseif msg:match("^opzioni") then f:Show(); mostraScheda("opzioni")
  elseif msg:match("^ess") or msg:match("^aure") then f:Show(); mostraScheda("essentials")
  else f:SetShown(not f:IsShown()) end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("CHAT_MSG_SYSTEM")
ev:RegisterEvent("CHAT_MSG_WHISPER")
ev:RegisterEvent("CHAT_MSG_GUILD")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("GUILD_ROSTER_UPDATE")
local giro = 0
ev:SetScript("OnEvent", function(_, evento, a1, a2, a3, a4)
  if evento == "PLAYER_LOGIN" then
    ERTDB = ERTDB or {}
    DB = ERTDB
    DB.raids = DB.raids or {}
    DB.opz = DB.opz or {}
    ERTIconDB = ERTIconDB or {}
    C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    pulisciVecchi()
    local P = type(_G.ERT_Ponte) == "table" and _G.ERT_Ponte or nil
    local novita = {}
    -- 1) raid annullati su Discord (/raid cancella): via subito, e non tornano piu' (nemmeno dalla gilda)
    if P and type(P.annullati) == "table" then
      for _, x in ipairs(P.annullati) do annullaEvento(tostring(x)) end
    end
    -- 2) raid portati dal ponte (file ERT_Dati.lua, scritto dal programma sul PC): nuovi o aggiornati
    if P and type(P.righe) == "table" then
      for _, riga in ipairs(P.righe) do
        local r = leggiRiga(riga)
        if r and r.inizio + 4 * 3600 > time() and not (DB.annullati and DB.annullati[eventoDi(r.id)]) then
          local prima = DB.raids[r.id]
          r.avvisi = prima and prima.avvisi or {}
          r.mio = true
          r.daPonte = true
          if prima then r.invDa, r.annunciato = prima.invDa, prima.annunciato end
          DB.raids[r.id] = r
          if not prima then novita[#novita + 1] = ("nuovo raid da Discord: |cffffd000%s|r del %s, ritrovo alle %s."):format(r.raid, date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio))
          elseif prima.riga ~= r.riga then novita[#novita + 1] = ("|cffffd000%s|r aggiornato da Discord (gruppi o orari)."):format(r.raid) end
        end
      end
      -- 3) raid del ponte che non ci sono piu' tra i miei (tolti, o non sono piu' referente)
      local ancora = {}
      for _, riga in ipairs(P.righe) do local id = tostring(riga):match("^RE1|([^|]+)|"); if id then ancora[id] = true end end
      for id, r in pairs(DB.raids) do if r.daPonte and not ancora[id] then toltoRaid(id) end end
    end
    -- 4) versioni di tutti i raid pubblicati: raid tolti da un evento, e raid importati a mano vecchi o mancanti
    if P and type(P.tutti) == "table" then
      local vivi, eventiVivi = {}, {}
      for _, x in ipairs(P.tutti) do if type(x) == "table" and x.id then vivi[x.id] = true; eventiVivi[x.ev or eventoDi(x.id)] = true end end
      for id in pairs(DB.raids) do if eventiVivi[eventoDi(id)] and not vivi[id] then toltoRaid(id) end end
      for _, x in ipairs(P.tutti) do if type(x) == "table" then controllaVersione(x) end end
      -- raid di oggi senza referenti e non pubblicati da me: dico una volta chi fara' gli inviti in gioco
      for _, x in ipairs(P.tutti) do
        local ts = type(x) == "table" and tonumber(x.ts) or 0
        if x.id and (x.refs or "") == "" and not (x.pub == true or x.pub == 1) and ts > time() and ts < time() + 18 * 3600
          and not (DB.annullati and DB.annullati[eventoDi(x.id)]) then
          avvisoUnaVolta(x.id .. ":senzaref", x.v, ("%s del %s alle %s non ha referenti: gli inviti in gioco li fa %s, che ha pubblicato i gruppi.")
            :format(x.nome or "Un raid", date("%d/%m", ts), date("%H:%M", ts), (x.da and x.da ~= "") and x.da or "chi ha pubblicato i gruppi"))
        end
      end
    end
    -- aure di gilda nuove o aggiornate (arrivano con ERT-Ponte)
    local daFa = #faDaImportare()
    if daFa > 0 then novita[#novita + 1] = ("aure di gilda: |cff40c040%d da importare|r (nuove o aggiornate): |cffffd000/ert essentials|r, un clic."):format(daFa) end
    if #novita > 0 then C_Timer.After(6, function() for _, t in ipairs(novita) do say(t) end end) end
    -- 5) ricevuta: appelli e messaggi "Contatta su Discord" che il ponte ha gia' portato su Discord
    if P and type(P.inviati) == "table" and DB.uscita then
      local fatti = {}
      for _, req in ipairs(P.inviati) do fatti[tostring(req)] = true end
      local resta, appelli, contatti = {}, 0, 0
      for _, riga in ipairs(DB.uscita) do
        local tipo, req = riga:match("^(R[CM]1)|([^|]+)|")
        if not (req and fatti[req]) then resta[#resta + 1] = riga
        elseif tipo == "RM1" then contatti = contatti + 1 else appelli = appelli + 1 end
      end
      DB.uscita = #resta > 0 and resta or nil
      C_Timer.After(6, function()
        if appelli > 0 then say(("|cff40c040arrivato su Discord|r: %d appell%s delle presenze."):format(appelli, appelli == 1 and "o" or "i")) end
        if contatti > 0 then say("|cff40c040mandati su Discord|r i messaggi a chi manca.") end
        if #resta > 0 then say(("%d cos%s ancora da portare su Discord: ERT-Ponte lo fa in pochi secondi (al prossimo /reload vedi la conferma)."):format(#resta, #resta == 1 and "a" or "e")) end
      end)
    end
    -- 6) chiedo agli ERT della gilda se ci sono novita' sui raid (rispondono quelli con ERT-Ponte), e passo le mie
    C_Timer.After(10, function() if IsInGuild() then C_ChatInfo.SendAddonMessage(PREFIX, "Q|", "GUILD") end end)
    C_Timer.After(15, mandaVersioni)
    C_Timer.After(6, function()
      avvisiPronti = true
      for _, t in ipairs(codaAvvisi) do avvisa(t) end
      wipe(codaAvvisi)
    end)
    mostraScheda("raid"); f:Hide()
    local LDB = LibStub and LibStub("LibDataBroker-1.1", true)
    icona = LibStub and LibStub("LibDBIcon-1.0", true)
    if LDB and icona then
      broker = LDB:NewDataObject("ERT", {
        type = "launcher", label = "ERT", icon = "Interface\\Icons\\Ability_Warrior_RallyingCry",
        OnClick = function(_, tasto)
          if tasto == "RightButton" then accendi(not attivo()) else f:SetShown(not f:IsShown()) end
        end,
        OnTooltipShow = function(tt)
          tt:AddLine("ERT · Ethereum Raid Tools")
          tt:AddLine(attivo() and "|cff0cd29fAcceso|r" or "|cff999999Spento|r", 1, 1, 1)
          local r = corrente()
          if r then tt:AddLine(("%s %s, ritrovo %s"):format(r.raid, date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio)), 1, 1, 1) end
          tt:AddLine("Clic: apri   ·   Clic destro: accendi / spegni", 0.7, 0.7, 0.7)
        end,
      })
      icona:Register("ERT", broker, ERTIconDB)
      ERT_AggiornaMinimappa()
    end
    -- popup degli inviti: all'ora del ritrovo, o appena il referente entra se il ritrovo e' gia' passato
    -- (fino all'inizio del raid: dopo, niente piu' automatico)
    local function controllaPopup()
      local ora = time()
      for _, r in pairs(DB.raids) do
        local rit = r.ritrovo or (r.inizio - 1800)
        r.avvisi = r.avvisi or {}
        if attivo() and opz("inviti") and sonoReferente(r) and ora >= rit and ora < r.inizio and not r.avvisi.popup
          and DB.auto ~= r.id and not r.invDa and not popInviti:IsShown() then
          r.avvisi.popup = true
          mostraPopupInviti(r)
          return
        end
      end
    end
    C_Timer.After(8, controllaPopup)
    C_Timer.NewTicker(15, function()
      controllaAvvisi()
      local ora = time()
      for _, r in pairs(DB.raids) do
        if r.mio and ora < r.inizio and ora - (r.mandato or 0) > 300 then manda(r) end
      end
      controllaPopup()
      if DB.auto then
        local r = DB.raids[DB.auto]
        if not r or not sonoReferente(r) or not attivo() then DB.auto = nil
        elseif ora >= (DB.autoFino or r.inizio) then
          DB.auto = nil
          avvisa(("%s e' iniziato: inviti e messaggi automatici spenti. Se serve, usa Invita ora e Rimetti nei gruppi."):format(r.raid))
        else
          giro = giro + 1
          if giro % 2 == 0 and IsInGuild() then C_GuildInfo.GuildRoster() end
          invitaOnline(r, true)
        end
      end
      aggiorna()
    end)
    C_Timer.After(5, controllaAvvisi)
  elseif evento == "CHAT_MSG_ADDON" and a1 == PREFIX then
    ricevi(a2, a4)
    aggiorna()
  elseif evento == "CHAT_MSG_SYSTEM" then
    messaggioSistema(a1)
    aggiorna()
  elseif evento == "CHAT_MSG_WHISPER" or evento == "CHAT_MSG_GUILD" then
    chiestoInvito(a1, a2) -- "inv" in privato o in gilda
  elseif evento == "GROUP_ROSTER_UPDATE" then
    if GetTime() - ultimoInvito < 600 then convertiInRaid() end
    sistemaPresto() -- chi e' appena entrato va nel suo gruppo
    aggiorna()
  elseif evento == "GUILD_ROSTER_UPDATE" then
    aggiorna()
  end
end)

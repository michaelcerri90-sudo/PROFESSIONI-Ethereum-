-------------------------------------------------------------------------------
-- ERT - Ethereum Raid Tools
--
-- Raid: i raid pubblicati dal bot di Discord (riga RE1 incollata dal referente
--       o, in futuro, portata dal "ponte"). Avvisi di ritrovo per chi e' nel raid;
--       per i referenti: popup al ritrovo, inviti automatici fino all'inizio,
--       inviti a chi e' online, sistema i gruppi.
-- Presenze: un officer sceglie il raid e fa l'appello alla gilda; chi ha ERT
--       risponde "ci sono / non ci sono" da un popup. Le risposte si salvano per
--       Discord (le portera' il ponte).
-- Opzioni: interruttori (acceso/spento, minimappa, avvisi, popup, suoni).
--
-- Riga RE1: RE1|id|raid|inizio|ritrovo|referenti(+)|gruppo1;gruppo2;...|panchina
-- Messaggi tra addon (prefisso ERT, canale gilda):
--   D|id|i|n|pezzo        un raid (a pezzi da 200 caratteri)
--   A|req|chiave|nome|inizio   appello presenze (dall'officer a tutta la gilda)
--   R|req|si / R|req|no   risposta all'appello (sussurro all'officer)
-------------------------------------------------------------------------------
local PREFIX = "ERT"
local VERSIONE = "2.0"
local function say(msg) DEFAULT_CHAT_FRAME:AddMessage("|cffffd000ERT:|r " .. msg) end

local DB
local raidAttivo
local invitati = {}
local ultimoInvito = -999

local function opz(k) return not DB or DB.opz == nil or DB.opz[k] ~= false end
local function attivo() return not DB or DB.enabled ~= false end
local function suono(id) if opz("suoni") then PlaySound(id, "Master") end end

-- ---------------------------------------------------------------- dati dei raid

local function pulisciNome(n)
  n = tostring(n or ""):gsub("%-.*$", "") -- "Nome-Reame" -> "Nome"
  return n
end

local function leggiRiga(riga)
  riga = tostring(riga or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local p = {}
  for campo in (riga .. "|"):gmatch("([^|]*)|") do p[#p + 1] = campo end
  if p[1] ~= "RE1" or #p < 7 then return nil end
  local r = { id = p[2], raid = p[3], inizio = tonumber(p[4]), ritrovo = tonumber(p[5]), refs = {}, gruppi = {}, panca = {} }
  if not r.id or r.id == "" or not r.inizio then return nil end
  for pezzo in (p[6] or ""):gmatch("[^+,]+") do
    local nome = pezzo:gsub("^%s+", ""):gsub("%s+$", "")
    if nome ~= "" then table.insert(r.refs, nome) end
  end
  r.ref = table.concat(r.refs, ", ")
  local g = 0
  for gruppo in (p[7] .. ";"):gmatch("([^;]*);") do
    g = g + 1
    r.gruppi[g] = {}
    for nome in gruppo:gmatch("[^,]+") do table.insert(r.gruppi[g], nome) end
  end
  for nome in (p[8] or ""):gmatch("[^,]+") do table.insert(r.panca, nome) end
  r.riga = riga
  return r
end

-- nome -> gruppo (panchina = 0)
local function postiDi(r)
  local posti = {}
  for g, lista in ipairs(r.gruppi) do for _, n in ipairs(lista) do posti[n] = g end end
  for _, n in ipairs(r.panca) do posti[n] = posti[n] or 0 end
  return posti
end

local function ordinati()
  local l = {}
  for _, r in pairs(DB.raids) do l[#l + 1] = r end
  table.sort(l, function(a, b) return a.inizio < b.inizio end)
  return l
end

local function pulisciVecchi()
  local ora = time()
  for id, r in pairs(DB.raids) do if r.inizio + 4 * 3600 < ora then DB.raids[id] = nil end end
end

-- ---------------------------------------------------------------- gilda e gruppo

local online, classi = {}, {}
local function aggiornaOnline()
  wipe(online)
  if not IsInGuild() then return end
  for i = 1, GetNumGuildMembers() do
    local nome, _, _, _, _, _, _, _, isOnline, _, classe = GetGuildRosterInfo(i)
    if nome then
      nome = pulisciNome(nome)
      if isOnline then online[nome] = true end
      if classe then classi[nome] = classe end
    end
  end
end

local function coloreClasse(nome, spento)
  if spento then return "|cff6b7480" end
  local c = classi[nome] and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classi[nome]]
  if not c then return "|cffe9e3d2" end
  return ("|cff%02x%02x%02x"):format(math.floor(c.r * 255 + 0.5), math.floor(c.g * 255 + 0.5), math.floor(c.b * 255 + 0.5))
end

local function nelGruppo()
  local n = {}
  n[UnitName("player")] = 0
  if IsInRaid() then
    for i = 1, GetNumGroupMembers() do
      local nome, _, sub = GetRaidRosterInfo(i)
      if nome then n[pulisciNome(nome)] = sub end
    end
  elseif IsInGroup() then
    for i = 1, GetNumSubgroupMembers() do
      local nome = UnitName("party" .. i)
      if nome then n[nome] = 1 end
    end
  end
  return n
end

local function invita(nome)
  if C_PartyInfo and C_PartyInfo.InviteUnit then C_PartyInfo.InviteUnit(nome) else InviteUnit(nome) end
  invitati[nome] = GetTime()
  ultimoInvito = GetTime()
end

local function convertiInRaid()
  if IsInGroup() and not IsInRaid() and UnitIsGroupLeader("player") then
    if C_PartyInfo and C_PartyInfo.ConvertToRaid then C_PartyInfo.ConvertToRaid() else ConvertToRaid() end
  end
end

-- referente del raid: nella riga ci sono i referenti; se non ci sono, chi l'ha importata
local function sonoReferente(r)
  if not r then return false end
  if not r.refs or #r.refs == 0 then return r.mio and true or false end
  local io = UnitName("player"):lower()
  for _, n in ipairs(r.refs) do if n:lower() == io then return true end end
  return false
end
local function soloReferenti(r)
  if sonoReferente(r) then return true end
  say(r and ("solo i referenti di " .. r.raid .. " (" .. (r.ref ~= "" and r.ref or "chi ha importato la riga") .. ") possono farlo.") or "nessun raid.")
  return false
end

-- officer della gilda (o referente di almeno un raid): puo' fare l'appello
local function sonoOfficer()
  if C_GuildInfo and C_GuildInfo.IsGuildOfficer then
    local ok, v = pcall(C_GuildInfo.IsGuildOfficer)
    if ok and v then return true end
  end
  if CanEditOfficerNote and CanEditOfficerNote() then return true end
  for _, r in pairs(DB and DB.raids or {}) do if sonoReferente(r) and r.refs and #r.refs > 0 then return true end end
  return false
end

-- invita chi e' nel raid (non la panchina), online e non ancora nel gruppo
local function invitaOnline(r, silenzioso)
  if not r then return 0 end
  if not sonoReferente(r) then
    if not silenzioso then soloReferenti(r) end
    return 0
  end
  if IsInGroup() and not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") then
    if not silenzioso then say("devi essere capo del gruppo o assistente per invitare.") end
    return 0
  end
  aggiornaOnline()
  local gia, n, posti = nelGruppo(), 0, postiDi(r)
  local maxParty = IsInRaid() and 40 or (IsInGroup() and (5 - GetNumGroupMembers()) or 4)
  for nome, g in pairs(posti) do
    if g > 0 and online[nome] and not gia[nome] and (GetTime() - (invitati[nome] or -999)) > 60 and n < maxParty then
      invita(nome)
      n = n + 1
    end
  end
  if not silenzioso then say(n > 0 and ("inviti mandati: " .. n .. ". Appena qualcuno accetta il gruppo diventa un raid.") or "nessuno da invitare: chi e' online e' gia' nel gruppo.") end
  return n
end

-- sposta ognuno nel gruppo deciso nella pagina di composizione
local function sistemaGruppi(r)
  if not r or not soloReferenti(r) then return end
  if not IsInRaid() then say("serve essere in raid.") return end
  if not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") then say("devi essere capo raid o assistente.") return end
  if InCombatLockdown() then say("non in combattimento.") return end
  local posti, giri = postiDi(r), 0
  local function passo()
    giri = giri + 1
    local membri, conta = {}, {}
    for i = 1, GetNumGroupMembers() do
      local nome, _, sub = GetRaidRosterInfo(i)
      if nome then
        membri[#membri + 1] = { i = i, nome = pulisciNome(nome), sub = sub }
        conta[sub] = (conta[sub] or 0) + 1
      end
    end
    local mosso = false
    for _, m in ipairs(membri) do
      local voglio = posti[m.nome]
      if voglio and voglio > 0 and voglio ~= m.sub then
        if (conta[voglio] or 0) < 5 then
          SetRaidSubgroup(m.i, voglio)
        else
          for _, altro in ipairs(membri) do
            if altro.sub == voglio and posti[altro.nome] ~= voglio then SwapRaidSubgroup(m.i, altro.i) break end
          end
        end
        mosso = true
        break
      end
    end
    if mosso and giri < 60 then C_Timer.After(0.3, passo)
    elseif not mosso then say("gruppi sistemati.")
    else say("non sono riuscito a sistemare tutti: riprova.") end
  end
  passo()
end

-- ---------------------------------------------------------------- grafica
-- Stile piatto e scuro (sul modello degli addon moderni tipo ElvUI e Details):
-- pannelli quasi neri, bordo sottile, oro Ethereum per titoli e azioni principali,
-- verde acqua per "acceso", nomi nei colori di classe.

local TMPL = BackdropTemplateMixin and "BackdropTemplate" or nil
local ORO = { 1, 0.82, 0 }
local ACQUA = { 0.05, 0.82, 0.62 }
local function pannello(parent, r, g, b, a, bordo)
  local p = CreateFrame("Frame", nil, parent, TMPL)
  p:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  p:SetBackdropColor(r or 0.05, g or 0.06, b or 0.08, a or 0.95)
  local c = bordo or { 0.17, 0.2, 0.26 }
  p:SetBackdropBorderColor(c[1], c[2], c[3], 1)
  return p
end
local function testo(parent, font, x, y, larg, punto)
  local t = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlightSmall")
  t:SetPoint(punto or "TOPLEFT", x or 0, y or 0)
  t:SetJustifyH("LEFT")
  if larg then t:SetWidth(larg) end
  return t
end
local function bottonePiatto(parent, etichetta, larg, alto, principale, fn)
  local b = CreateFrame("Button", nil, parent, TMPL)
  b:SetSize(larg, alto or 24)
  b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  b.principale = principale
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  b.t:SetPoint("CENTER"); b.t:SetText(etichetta)
  function b:Colora(sopra)
    if not self:IsEnabled() then
      self:SetBackdropColor(0.1, 0.1, 0.12, 1); self:SetBackdropBorderColor(0.2, 0.2, 0.24, 1); self.t:SetTextColor(0.4, 0.4, 0.45)
    elseif self.principale then
      self:SetBackdropColor(ORO[1], ORO[2], ORO[3], sopra and 1 or 0.88); self:SetBackdropBorderColor(1, 0.9, 0.4, 1); self.t:SetTextColor(0.1, 0.08, 0)
    else
      self:SetBackdropColor(0.12, 0.14, 0.18, 1)
      self:SetBackdropBorderColor(sopra and ORO[1] or 0.25, sopra and ORO[2] or 0.28, sopra and ORO[3] or 0.34, 1)
      self.t:SetTextColor(0.92, 0.9, 0.85)
    end
  end
  b:SetScript("OnEnter", function(self) self:Colora(true) end)
  b:SetScript("OnLeave", function(self) self:Colora(false) end)
  b:SetScript("OnEnable", function(self) self:Colora(false) end)
  b:SetScript("OnDisable", function(self) self:Colora(false) end)
  b:SetScript("OnClick", fn)
  b:Colora(false)
  return b
end
-- interruttore a slitta ON/OFF
local function interruttore(parent, acceso, fn)
  local s = CreateFrame("Button", nil, parent, TMPL)
  s:SetSize(58, 22)
  s:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  s.pallino = s:CreateTexture(nil, "OVERLAY"); s.pallino:SetSize(18, 18); s.pallino:SetColorTexture(1, 1, 1, 1)
  s.t = s:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  function s:Aggiorna()
    local on = acceso()
    local spento = not self:IsEnabled()
    self:SetBackdropColor(on and ACQUA[1] * 0.6 or 0.12, on and ACQUA[2] * 0.6 or 0.13, on and ACQUA[3] * 0.6 or 0.16, spento and 0.4 or 1)
    self:SetBackdropBorderColor(on and ACQUA[1] or 0.25, on and ACQUA[2] or 0.28, on and ACQUA[3] or 0.34, 1)
    self.pallino:ClearAllPoints(); self.pallino:SetPoint(on and "RIGHT" or "LEFT", on and -2 or 2, 0)
    self.t:ClearAllPoints(); self.t:SetPoint(on and "LEFT" or "RIGHT", on and 8 or -8, 0)
    self.t:SetText(on and "ON" or "OFF")
    self.t:SetTextColor(1, 1, 1, spento and 0.4 or 1)
  end
  s:SetScript("OnClick", function(self) fn(); self:Aggiorna() end)
  return s
end
local ICONA_SI = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14|t"
local ICONA_NO = "|TInterface\\RaidFrame\\ReadyCheck-NotReady:14|t"
local ICONA_ATTESA = "|TInterface\\RaidFrame\\ReadyCheck-Waiting:14|t"
local ICONA_ON = "|TInterface\\COMMON\\Indicator-Green:12|t"
local ICONA_OFF = "|TInterface\\COMMON\\Indicator-Gray:12|t"

-- ---------------------------------------------------------------- avvisi

local function avvisa(t)
  RaidNotice_AddMessage(RaidWarningFrame, t, ChatTypeInfo["RAID_WARNING"])
  suono(SOUNDKIT and SOUNDKIT.RAID_WARNING or 8959)
  if FlashClientIcon then FlashClientIcon() end
  say(t)
end

local function controllaAvvisi()
  if not attivo() or not opz("avvisi") then return end
  local ora, io = time(), UnitName("player")
  for _, r in pairs(DB.raids) do
    local posto = postiDi(r)[io]
    local rit = r.ritrovo or r.inizio
    r.avvisi = r.avvisi or {}
    if posto and ora < r.inizio + 3600 then
      local chi = (r.ref and r.ref ~= "") and ((#r.refs > 1 and " Referenti: " or " Referente: ") .. r.ref .. ".") or ""
      local dove = posto == 0 and " (sei in panchina)" or (" (gruppo " .. posto .. ")")
      if not r.avvisi.pre and ora >= rit - 15 * 60 and ora < rit then
        r.avvisi.pre = true
        avvisa(("Tra 15 minuti si gruppa per %s%s.%s"):format(r.raid, dove, chi))
      end
      if not r.avvisi.ora and ora >= rit then
        r.avvisi.ora = true
        avvisa(("E' ora di gruppare per %s%s!%s"):format(r.raid, dove, chi))
      end
    end
  end
end

-- ---------------------------------------------------------------- popup (inviti e appello)

local function popupBase(icona, alto)
  local p = pannello(UIParent, 0.04, 0.05, 0.07, 0.97, ORO)
  p:SetSize(390, alto or 170); p:SetPoint("TOP", 0, -140); p:SetFrameStrata("DIALOG"); p:Hide()
  p:EnableMouse(true); p:SetMovable(true); p:RegisterForDrag("LeftButton")
  p:SetScript("OnDragStart", p.StartMoving); p:SetScript("OnDragStop", p.StopMovingOrSizing)
  local ic = p:CreateTexture(nil, "ARTWORK"); ic:SetSize(48, 48); ic:SetPoint("TOPLEFT", 16, -16); ic:SetTexture(icona)
  p.titolo = testo(p, "GameFontNormalLarge", 76, -16, 300)
  p.sotto = testo(p, "GameFontHighlight", 76, -40, 300)
  p.info = testo(p, "GameFontDisableSmall", 76, -62, 300)
  return p
end

local popInviti = popupBase("Interface\\Icons\\Ability_Warrior_RallyingCry")
popInviti.si = bottonePiatto(popInviti, "Avvia inviti", 160, 30, true, function()
  local r = popInviti.raid; popInviti:Hide()
  if not r then return end
  DB.auto = r.id
  say(("inviti automatici ACCESI per %s fino alle %s."):format(r.raid, date("%H:%M", r.inizio)))
  invitaOnline(r)
end)
popInviti.si:SetPoint("BOTTOMLEFT", 16, 16)
popInviti.no = bottonePiatto(popInviti, "Non ora", 120, 30, false, function() popInviti:Hide() say("ok: puoi avviarli quando vuoi da /ert.") end)
popInviti.no:SetPoint("BOTTOMRIGHT", -16, 16)

local function mostraPopupInviti(r)
  popInviti.raid = r
  aggiornaOnline()
  local tot, on = 0, 0
  for nome, g in pairs(postiDi(r)) do if g > 0 then tot = tot + 1; if online[nome] then on = on + 1 end end end
  popInviti.titolo:SetText("E' ora di gruppare!")
  popInviti.sotto:SetText(("%s · inizio alle %s"):format(r.raid, date("%H:%M", r.inizio)))
  popInviti.info:SetText(("Online adesso: %d su %d. Invito subito chi c'e' e poi chi entra in gioco, fino all'inizio del raid."):format(on, tot))
  popInviti:Show()
  suono(SOUNDKIT and SOUNDKIT.READY_CHECK or 8960)
  if FlashClientIcon then FlashClientIcon() end
end

-- popup dell'appello (per tutti i giocatori della gilda con ERT)
local popAppello = popupBase("Interface\\Icons\\INV_Misc_Note_01", 160)
local function rispondi(si)
  local a = popAppello.appello; popAppello:Hide()
  if not a then return end
  DB.risposte = DB.risposte or {}
  DB.risposte[a.req] = si and "si" or "no"
  C_ChatInfo.SendAddonMessage(PREFIX, "R|" .. a.req .. "|" .. (si and "si" or "no"), "WHISPER", a.da)
  say(si and ("segnato presente a " .. a.nome .. ".") or ("segnato assente a " .. a.nome .. "."))
end
popAppello.si = bottonePiatto(popAppello, "Ci sono", 150, 30, true, function() rispondi(true) end)
popAppello.si:SetPoint("BOTTOMLEFT", 16, 16)
popAppello.no = bottonePiatto(popAppello, "Non ci sono", 150, 30, false, function() rispondi(false) end)
popAppello.no:SetPoint("BOTTOMRIGHT", -16, 16)

local function mostraAppello(a)
  if not attivo() or not opz("appello") then return end
  popAppello.appello = a
  popAppello.titolo:SetText("Appello raid")
  popAppello.sotto:SetText(("%s · %s"):format(a.nome, a.inizio and a.inizio > 0 and date("%d/%m alle %H:%M", a.inizio) or ""))
  popAppello.info:SetText(("Te lo chiede %s. Rispondi e ti segno io su Discord."):format(a.da))
  popAppello:Show()
  suono(SOUNDKIT and SOUNDKIT.READY_CHECK or 8960)
  if FlashClientIcon then FlashClientIcon() end
end

-- ---------------------------------------------------------------- messaggi tra addon (gilda)

local inArrivo = {}
local function manda(r)
  if not IsInGuild() or not r.riga then return end
  local riga, pezzi = r.riga, {}
  for i = 1, #riga, 200 do pezzi[#pezzi + 1] = riga:sub(i, i + 199) end
  for i, pezzo in ipairs(pezzi) do
    C_ChatInfo.SendAddonMessage(PREFIX, "D|" .. r.id .. "|" .. i .. "|" .. #pezzi .. "|" .. pezzo, "GUILD")
  end
  r.mandato = time()
end

local aggiorna -- la finestra (sotto)
local function riceviRaid(testoMsg, mittente)
  local id, i, n, pezzo = testoMsg:match("^D|([^|]+)|(%d+)|(%d+)|(.*)$")
  if not id then return end
  i, n = tonumber(i), tonumber(n)
  local buf = inArrivo[id] or { n = n, parti = {} }
  inArrivo[id] = buf
  buf.parti[i] = pezzo
  for k = 1, n do if not buf.parti[k] then return end end
  inArrivo[id] = nil
  local r = leggiRiga(table.concat(buf.parti))
  if not r then return end
  local prima = DB.raids[r.id]
  r.da = pulisciNome(mittente)
  r.avvisi = prima and prima.avvisi or {}
  r.mio = prima and prima.mio
  DB.raids[r.id] = r
  local io = UnitName("player")
  if attivo() and postiDi(r)[io] and not (prima and prima.riga == r.riga) then
    say(("sei nel raid |cffffd000%s|r del %s: ritrovo alle %s."):format(r.raid, date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio)))
  end
end

local function ricevi(testoMsg, mittente)
  local io = UnitName("player")
  mittente = pulisciNome(mittente)
  local tipo = testoMsg:sub(1, 2)
  if tipo == "D|" then riceviRaid(testoMsg, mittente)
  elseif tipo == "A|" then
    local req, chiave, nome, inizio = testoMsg:match("^A|([^|]+)|([^|]*)|([^|]*)|(%d*)$")
    if req and mittente ~= io and not (DB.risposte and DB.risposte[req]) then
      mostraAppello({ req = req, chiave = chiave, nome = nome, inizio = tonumber(inizio), da = mittente })
    end
  elseif tipo == "R|" then
    local req, risp = testoMsg:match("^R|([^|]+)|(%a+)$")
    local a = DB.appello
    if req and a and a.req == req and not a.chiuso then
      a.risposte[mittente] = risp == "si" and "si" or "no"
    end
  end
end

-- ---------------------------------------------------------------- finestra principale

local f = pannello(UIParent)
f:SetSize(540, 640); f:SetPoint("CENTER"); f:SetFrameStrata("HIGH")
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
f:Hide()
_G.ERTFrame = f
tinsert(UISpecialFrames, "ERTFrame")

local barra = pannello(f, 0.08, 0.09, 0.12, 1)
barra:SetPoint("TOPLEFT", 1, -1); barra:SetPoint("TOPRIGHT", -1, -1); barra:SetHeight(32)
local logo = barra:CreateTexture(nil, "ARTWORK"); logo:SetSize(22, 22); logo:SetPoint("LEFT", 8, 0); logo:SetTexture("Interface\\Icons\\Ability_Warrior_RallyingCry")
local titolo = testo(barra, "GameFontNormalLarge", 38, 0, nil, "LEFT"); titolo:SetText("ERT")
local sottotitolo = testo(barra, "GameFontDisableSmall", 80, -1, nil, "LEFT"); sottotitolo:SetText("Ethereum Raid Tools")
local statoTesta = testo(barra, "GameFontNormalSmall", -40, 0, nil, "RIGHT"); statoTesta:SetJustifyH("RIGHT")
local chiudi = bottonePiatto(barra, "x", 24, 24, false, function() f:Hide() end); chiudi:SetPoint("RIGHT", -4, 0)

-- schede
local schede, pagine, schedaAttiva = {}, {}, "raid"
local function mostraScheda(nome)
  schedaAttiva = nome
  for k, p in pairs(pagine) do p:SetShown(k == nome) end
  for k, b in pairs(schede) do
    b.riga:SetShown(k == nome)
    b.t:SetTextColor(k == nome and ORO[1] or 0.6, k == nome and ORO[2] or 0.62, k == nome and ORO[3] or 0.66)
  end
  if aggiorna then aggiorna() end
end
local function scheda(nome, etichetta, x)
  local b = CreateFrame("Button", nil, f)
  b:SetSize(120, 28); b:SetPoint("TOPLEFT", x, -36)
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontNormal"); b.t:SetPoint("CENTER"); b.t:SetText(etichetta)
  b.riga = b:CreateTexture(nil, "OVERLAY"); b.riga:SetColorTexture(ORO[1], ORO[2], ORO[3], 1); b.riga:SetHeight(2)
  b.riga:SetPoint("BOTTOMLEFT", 8, 0); b.riga:SetPoint("BOTTOMRIGHT", -8, 0)
  b:SetScript("OnClick", function() mostraScheda(nome) end)
  schede[nome] = b
  local p = CreateFrame("Frame", nil, f)
  p:SetPoint("TOPLEFT", 0, -66); p:SetPoint("BOTTOMRIGHT", 0, 0)
  pagine[nome] = p
  return p
end
local pRaid = scheda("raid", "Raid", 8)
local pPres = scheda("presenze", "Presenze", 128)
local pOpz = scheda("opzioni", "Opzioni", 248)
local separatore = f:CreateTexture(nil, "ARTWORK"); separatore:SetColorTexture(0.17, 0.2, 0.26, 1); separatore:SetHeight(1)
separatore:SetPoint("TOPLEFT", 1, -65); separatore:SetPoint("TOPRIGHT", -1, -65)

local function corrente()
  local l = ordinati()
  if raidAttivo and DB.raids[raidAttivo] then return DB.raids[raidAttivo], l end
  raidAttivo = l[1] and l[1].id
  return l[1], l
end

-- ---------- scheda Raid
local boxImp = pannello(pRaid, 0.03, 0.035, 0.05, 1)
boxImp:SetPoint("TOPLEFT", 12, -10); boxImp:SetSize(420, 26)
local campo = CreateFrame("EditBox", nil, boxImp)
campo:SetPoint("TOPLEFT", 6, -4); campo:SetPoint("BOTTOMRIGHT", -6, 4)
campo:SetFontObject("GameFontHighlightSmall"); campo:SetAutoFocus(false); campo:SetMaxLetters(3000)
campo:SetScript("OnEscapePressed", campo.ClearFocus)
local suggerimento = testo(boxImp, "GameFontDisableSmall", 8, 0, 400, "LEFT"); suggerimento:SetText("Incolla qui la stringa che il bot ti ha mandato su Discord")
campo:SetScript("OnTextChanged", function(self) suggerimento:SetShown(self:GetText() == "") end)
local bImporta = bottonePiatto(pRaid, "Importa", 84, 26, true, function()
  local r = leggiRiga(campo:GetText())
  if not r then say("stringa non valida: copiala di nuovo dal messaggio del bot.") return end
  local prima = DB.raids[r.id]
  r.avvisi = prima and prima.avvisi or {}
  r.mio = true
  DB.raids[r.id] = r
  raidAttivo = r.id
  campo:SetText(""); campo:ClearFocus()
  manda(r)
  say(("importato %s: all'ora del ritrovo ti chiedo se far partire gli inviti."):format(r.raid))
  aggiorna()
end)
bImporta:SetPoint("TOPRIGHT", -12, -10)

local bPrima = bottonePiatto(pRaid, "<", 26, 26, false, function()
  local _, l = corrente()
  for k, x in ipairs(l) do if x.id == raidAttivo then raidAttivo = (l[k - 1] or l[#l]).id break end end
  aggiorna()
end)
bPrima:SetPoint("TOPRIGHT", -42, -46)
local bDopo = bottonePiatto(pRaid, ">", 26, 26, false, function()
  local _, l = corrente()
  for k, x in ipairs(l) do if x.id == raidAttivo then raidAttivo = (l[k + 1] or l[1]).id break end end
  aggiorna()
end)
bDopo:SetPoint("TOPRIGHT", -12, -46)
local nomeRaid = testo(pRaid, "GameFontNormalHuge", 14, -46, 420)
local quando = testo(pRaid, "GameFontHighlight", 14, -74, 510)
local chiRef = testo(pRaid, "GameFontDisableSmall", 14, -92, 510)
local stato = testo(pRaid, "GameFontHighlightSmall", 14, -110, 510)

local rigaAuto = pannello(pRaid, 0.07, 0.08, 0.11, 1)
rigaAuto:SetPoint("TOPLEFT", 12, -130); rigaAuto:SetPoint("TOPRIGHT", -12, -130); rigaAuto:SetHeight(40)
local autoTesto = testo(rigaAuto, "GameFontHighlight", 10, 0, 400, "LEFT")
local swAuto = interruttore(rigaAuto, function() local r = corrente(); return r and DB.auto == r.id end, function()
  local r = corrente()
  if not r or not soloReferenti(r) then return end
  DB.auto = DB.auto ~= r.id and r.id or nil
  say(DB.auto and ("inviti automatici ACCESI per %s fino alle %s."):format(r.raid, date("%H:%M", r.inizio)) or "inviti automatici spenti.")
  if DB.auto then invitaOnline(r, true) end
  aggiorna()
end)
swAuto:SetPoint("RIGHT", -10, 0)

local riquadri = {}
for g = 1, 8 do
  local q = pannello(pRaid, 0.07, 0.08, 0.11, 1)
  q:SetSize(252, 80)
  q:SetPoint("TOPLEFT", 12 + ((g - 1) % 2) * 264, -178 - math.floor((g - 1) / 2) * 86)
  q.titolo = testo(q, "GameFontNormalSmall", 6, -4)
  q.titolo:SetText("Gruppo " .. g)
  q.righe = {}
  for i = 1, 5 do q.righe[i] = testo(q, "GameFontHighlightSmall", 8, -5 - i * 13, 238) end
  riquadri[g] = q
end
local panca = testo(pRaid, "GameFontHighlightSmall", 14, -526, 510)
local legenda = testo(pRaid, "GameFontDisableSmall", 14, -542, 510)
legenda:SetText(ICONA_SI .. " nel gruppo    " .. ICONA_ON .. " online    " .. ICONA_OFF .. " offline")
local bInvita = bottonePiatto(pRaid, "Invita ora", 130, 28, true, function() invitaOnline((corrente())) end)
bInvita:SetPoint("BOTTOMLEFT", 12, 12)
local bGruppi = bottonePiatto(pRaid, "Sistema gruppi", 140, 28, false, function() sistemaGruppi((corrente())) end)
bGruppi:SetPoint("LEFT", bInvita, "RIGHT", 6, 0)
local bAnnuncia = bottonePiatto(pRaid, "Annuncia alla gilda", 160, 28, false, function()
  local r = corrente()
  if r then manda(r) say("raid mandato di nuovo agli addon della gilda.") end
end)
bAnnuncia:SetPoint("LEFT", bGruppi, "RIGHT", 6, 0)

local function aggiornaRaid()
  local r, l = corrente()
  local ref = r and sonoReferente(r) and true or false
  bInvita:SetEnabled(ref); bGruppi:SetEnabled(ref); swAuto:SetEnabled(ref)
  bPrima:SetShown(#l > 1); bDopo:SetShown(#l > 1)
  if not r then
    nomeRaid:SetText("Nessun raid in programma")
    quando:SetText("Quando i gruppi vengono pubblicati, il bot manda la stringa ai referenti.")
    chiRef:SetText("Gli altri lo ricevono da soli dall'ERT del referente.")
    stato:SetText(""); panca:SetText(""); autoTesto:SetText("")
    for g = 1, 8 do riquadri[g]:Hide() end
    swAuto:Aggiorna()
    return
  end
  aggiornaOnline()
  local gia = nelGruppo()
  local pos = 0
  for k, x in ipairs(l) do if x.id == r.id then pos = k end end
  nomeRaid:SetText(r.raid .. (#l > 1 and ("  |cff9aa3ae" .. pos .. "/" .. #l .. "|r") or ""))
  quando:SetText(("%s     |cffffd000Ritrovo|r %s     |cffffd000Inizio|r %s"):format(date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio - 1800), date("%H:%M", r.inizio)))
  chiRef:SetText((r.ref and r.ref ~= "") and ((#r.refs > 1 and "Referenti: " or "Referente: ") .. r.ref) or "Referente: chi ha importato la stringa")
  local tot, on, dentro = 0, 0, 0
  local function nome(n)
    local icona = gia[n] and ICONA_SI or online[n] and ICONA_ON or ICONA_OFF
    return icona .. " " .. coloreClasse(n, not online[n] and not gia[n]) .. n .. "|r"
  end
  for g = 1, 8 do
    local lista = r.gruppi[g] or {}
    local q = riquadri[g]
    if g <= math.max(1, #r.gruppi) then
      q:Show()
      for i = 1, 5 do
        local n = lista[i]
        q.righe[i]:SetText(n and nome(n) or "")
        if n then tot = tot + 1; if online[n] then on = on + 1 end; if gia[n] then dentro = dentro + 1 end end
      end
    else
      q:Hide()
    end
  end
  local p = {}
  for _, n in ipairs(r.panca) do p[#p + 1] = nome(n) end
  panca:SetText(#p > 0 and ("|cffffd000Panchina|r   " .. table.concat(p, "   ")) or "")
  stato:SetText(("Online |cff40c040%d|r su %d     nel gruppo |cffffffff%d|r"):format(on, tot, dentro))
  autoTesto:SetText(ref and ("|cffffd000Inviti automatici|r  |cff9aa3aedal ritrovo fino alle " .. date("%H:%M", r.inizio) .. "|r")
    or "|cff6b7480Inviti automatici: solo per i referenti di questo raid|r")
  swAuto:Aggiorna()
end

-- ---------- scheda Presenze (appello)
local presTitolo = testo(pPres, "GameFontNormalLarge", 14, -12, 510)
presTitolo:SetText("Appello presenze")
local presAiuto = testo(pPres, "GameFontDisableSmall", 14, -34, 510)
presAiuto:SetText("Scegli il raid e chiedi alla gilda chi c'e'. Chi ha ERT risponde da un popup: chi dice si' viene segnato al raid su Discord.")
local selRaid = pannello(pPres, 0.07, 0.08, 0.11, 1)
selRaid:SetPoint("TOPLEFT", 12, -62); selRaid:SetPoint("TOPRIGHT", -12, -62); selRaid:SetHeight(44)
local selNome = testo(selRaid, "GameFontNormal", 44, -8, 420)
local selQuando = testo(selRaid, "GameFontDisableSmall", 44, -26, 420)
local scelto = 1
local function raidPerAppello()
  local l = {}
  for _, r in ipairs(ordinati()) do l[#l + 1] = { chiave = r.id, nome = r.raid, inizio = r.inizio } end
  local ponte = _G.ERT_Ponte
  if type(ponte) == "table" and type(ponte.eventi) == "table" then
    for _, e in ipairs(ponte.eventi) do
      for _, x in ipairs(e.raids or {}) do l[#l + 1] = { chiave = e.id .. ":" .. x.k, nome = x.nome, inizio = x.ts } end
    end
  end
  return l
end
local selPrima = bottonePiatto(selRaid, "<", 26, 26, false, function() scelto = scelto - 1; aggiorna() end)
selPrima:SetPoint("LEFT", 8, 0)
local selDopo = bottonePiatto(selRaid, ">", 26, 26, false, function() scelto = scelto + 1; aggiorna() end)
selDopo:SetPoint("RIGHT", -8, 0)

local bChiedi = bottonePiatto(pPres, "Chiedi presenze alla gilda", 230, 30, true, function()
  local l = raidPerAppello()
  local x = l[scelto]
  if not x then say("non c'e' nessun raid da scegliere.") return end
  if not sonoOfficer() then say("l'appello lo possono fare gli officer e i referenti.") return end
  local req = tostring(time()) .. math.random(100, 999)
  DB.appello = { req = req, chiave = x.chiave, nome = x.nome, inizio = x.inizio, t = time(), risposte = {} }
  C_ChatInfo.SendAddonMessage(PREFIX, ("A|%s|%s|%s|%d"):format(req, x.chiave, (x.nome or ""):gsub("|", ""), x.inizio or 0), "GUILD")
  if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
  say(("appello mandato alla gilda per %s."):format(x.nome))
  aggiorna()
end)
bChiedi:SetPoint("TOPLEFT", 12, -116)
local bAnch = bottonePiatto(pPres, "Ci sono anch'io", 140, 30, false, function()
  local a = DB.appello
  if a and not a.chiuso then a.risposte[UnitName("player")] = "si"; aggiorna() end
end)
bAnch:SetPoint("LEFT", bChiedi, "RIGHT", 8, 0)
local presStato = testo(pPres, "GameFontHighlight", 14, -156, 510)
local colonne = {}
for c = 1, 2 do
  colonne[c] = testo(pPres, "GameFontHighlightSmall", 14 + (c - 1) * 262, -178, 250)
  colonne[c]:SetJustifyV("TOP"); colonne[c]:SetHeight(330)
end
local bSalva = bottonePiatto(pPres, "Chiudi appello e salva", 200, 28, true, function()
  local a = DB.appello
  if not a or a.chiuso then return end
  a.chiuso = true
  local si, no = {}, {}
  for n, v in pairs(a.risposte) do if v == "si" then si[#si + 1] = n else no[#no + 1] = n end end
  DB.uscita = DB.uscita or {}
  DB.uscita[#DB.uscita + 1] = ("RC1|%s|%s|%d|%s|%s"):format(a.req, a.chiave, time(), table.concat(si, ","), table.concat(no, ","))
  say(("appello chiuso: %d presenti, %d assenti. Il ponte lo porta su Discord al prossimo /reload."):format(#si, #no))
  aggiorna()
end)
bSalva:SetPoint("BOTTOMLEFT", 12, 12)
local bRicarica = bottonePiatto(pPres, "Ricarica e manda a Discord", 210, 28, false, function() ReloadUI() end)
bRicarica:SetPoint("LEFT", bSalva, "RIGHT", 6, 0)

local function aggiornaPresenze()
  local l = raidPerAppello()
  if scelto > #l then scelto = 1 elseif scelto < 1 then scelto = #l end
  local x = l[scelto]
  selNome:SetText(x and x.nome or "Nessun raid in programma")
  selQuando:SetText(x and x.inizio and x.inizio > 0 and date("%d/%m alle %H:%M", x.inizio) or "Importa un raid nella scheda Raid (o aspetta il ponte)")
  selPrima:SetShown(#l > 1); selDopo:SetShown(#l > 1)
  local off = sonoOfficer()
  bChiedi:SetEnabled(off and x ~= nil)
  local a = DB.appello
  bAnch:SetEnabled(a ~= nil and not a.chiuso)
  bSalva:SetEnabled(a ~= nil and not a.chiuso)
  bRicarica:SetEnabled(DB.uscita ~= nil and #DB.uscita > 0)
  if not off then
    presStato:SetText("|cff6b7480L'appello lo possono fare gli officer e i referenti. Quando qualcuno lo fa, ti compare un popup.|r")
    colonne[1]:SetText(""); colonne[2]:SetText("")
    return
  end
  if not a then
    presStato:SetText("Nessun appello in corso.")
    colonne[1]:SetText(""); colonne[2]:SetText("")
    return
  end
  aggiornaOnline()
  local voci, si, no, attesa = {}, 0, 0, 0
  local visti = {}
  for n, v in pairs(a.risposte) do voci[#voci + 1] = { n = n, v = v }; visti[n] = true end
  if not a.chiuso then for n in pairs(online) do if not visti[n] then voci[#voci + 1] = { n = n, v = "attesa" } end end end
  local ordine = { si = 1, no = 2, attesa = 3 }
  table.sort(voci, function(p, q) if ordine[p.v] ~= ordine[q.v] then return ordine[p.v] < ordine[q.v] end return p.n < q.n end)
  local righe = { {}, {} }
  for i, v in ipairs(voci) do
    if v.v == "si" then si = si + 1 elseif v.v == "no" then no = no + 1 else attesa = attesa + 1 end
    if i <= 44 then
      local icona = v.v == "si" and ICONA_SI or v.v == "no" and ICONA_NO or ICONA_ATTESA
      table.insert(righe[i <= 22 and 1 or 2], icona .. " " .. coloreClasse(v.n, v.v == "attesa") .. v.n .. "|r")
    end
  end
  presStato:SetText(("%s%s   |cff40c040%d si'|r   |cffff6b5a%d no|r   |cff9aa3ae%d senza risposta|r"):format(
    a.chiuso and "|cff9aa3aeChiuso|r  " or "|cffffd000In corso|r  ", a.nome, si, no, attesa))
  colonne[1]:SetText(table.concat(righe[1], "\n")); colonne[2]:SetText(table.concat(righe[2], "\n"))
end

-- ---------- scheda Opzioni
local opzTitolo = testo(pOpz, "GameFontNormalLarge", 14, -12, 510); opzTitolo:SetText("Opzioni")
local voci = {
  { k = "enabled", t = "ERT acceso", d = "Spento: niente avvisi, popup e inviti automatici (la finestra resta apribile).",
    get = function() return attivo() end, set = function() DB.enabled = not attivo() end },
  { k = "minimappa", t = "Bottone sulla minimappa", d = "Il bottone rotondo di ERT. Con la barra BottoniMinimappa c'e' anche il bottone li'.",
    get = function() return ERT_MinimappaVisibile and ERT_MinimappaVisibile() end, set = function() DB.opz.minimappa = not ERT_MinimappaVisibile(); ERT_AggiornaMinimappa() end },
  { k = "avvisi", t = "Avvisi di ritrovo", d = "15 minuti prima e all'ora del ritrovo, se sei nel raid.",
    get = function() return opz("avvisi") end, set = function() DB.opz.avvisi = not opz("avvisi") end },
  { k = "appello", t = "Popup dell'appello", d = "Quando un officer chiede chi c'e', ti compare il popup per rispondere.",
    get = function() return opz("appello") end, set = function() DB.opz.appello = not opz("appello") end },
  { k = "suoni", t = "Suoni", d = "Suono di avviso per ritrovo, popup degli inviti e appello.",
    get = function() return opz("suoni") end, set = function() DB.opz.suoni = not opz("suoni") end },
}
local interruttoriOpz = {}
for i, v in ipairs(voci) do
  local r = pannello(pOpz, 0.07, 0.08, 0.11, 1)
  r:SetPoint("TOPLEFT", 12, -40 - (i - 1) * 58); r:SetPoint("TOPRIGHT", -12, -40 - (i - 1) * 58); r:SetHeight(50)
  local t1 = testo(r, "GameFontNormal", 10, -9, 420); t1:SetText(v.t)
  local t2 = testo(r, "GameFontDisableSmall", 10, -27, 420); t2:SetText(v.d)
  local s = interruttore(r, v.get, function() v.set(); if ERT_AggiornaBottone then ERT_AggiornaBottone() end end)
  s:SetPoint("RIGHT", -10, 0)
  interruttoriOpz[#interruttoriOpz + 1] = s
end
local versione = testo(pOpz, "GameFontDisableSmall", 14, -340, 510)
versione:SetText("ERT " .. VERSIONE .. " · /ert apre questa finestra · /ert on, /ert off, /ert invita, /ert gruppi")

aggiorna = function()
  if not f:IsShown() or not DB then return end
  statoTesta:SetText(attivo() and "|cff0cd29facceso|r" or "|cff999999spento|r")
  if schedaAttiva == "raid" then aggiornaRaid()
  elseif schedaAttiva == "presenze" then aggiornaPresenze()
  else for _, s in ipairs(interruttoriOpz) do s:Aggiorna() end end
end
f:SetScript("OnShow", function() if IsInGuild() and C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end aggiorna() end)

-- ---------------------------------------------------------------- minimappa, comandi, eventi

local broker, icona
local function minimappaVisibile()
  if DB.opz.minimappa ~= nil then return DB.opz.minimappa ~= false end
  -- con la barra BottoniMinimappa il bottone c'e' gia' li'
  local caricata = (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("BottoniMinimappa")) or (IsAddOnLoaded and IsAddOnLoaded("BottoniMinimappa"))
  return not caricata
end
ERT_MinimappaVisibile = minimappaVisibile
function ERT_AggiornaMinimappa()
  if not icona then return end
  if minimappaVisibile() then icona:Show("ERT") else icona:Hide("ERT") end
end
function ERT_AggiornaBottone()
  if broker then broker.icon = "Interface\\Icons\\Ability_Warrior_RallyingCry" end
  if ERT_BottoneBarra then ERT_BottoneBarra() end
end
-- per la barra BottoniMinimappa: acceso o spento
function ERT_Acceso() return attivo() end

local function accendi(v)
  DB.enabled = v
  if not v then DB.auto = nil end
  say(v and "acceso." or "spento: niente avvisi, popup e inviti automatici.")
  ERT_AggiornaBottone()
  aggiorna()
end

SLASH_ERT1 = "/ert"
SLASH_ERT2 = "/raideth"
SlashCmdList.ERT = function(msg)
  msg = (msg or ""):lower()
  if msg == "on" then accendi(true)
  elseif msg == "off" then accendi(false)
  elseif msg == "toggle" then accendi(not attivo())
  elseif msg:match("^invita") then invitaOnline((corrente()))
  elseif msg:match("^gruppi") then sistemaGruppi((corrente()))
  elseif msg:match("^presenze") then f:Show(); mostraScheda("presenze")
  elseif msg:match("^opzioni") then f:Show(); mostraScheda("opzioni")
  else f:SetShown(not f:IsShown()) end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("CHAT_MSG_SYSTEM")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("GUILD_ROSTER_UPDATE")
local giro = 0
ev:SetScript("OnEvent", function(_, evento, a1, a2, a3, a4)
  if evento == "PLAYER_LOGIN" then
    ERTDB = ERTDB or {}
    DB = ERTDB
    DB.raids = DB.raids or {}
    DB.opz = DB.opz or {}
    ERTIconDB = ERTIconDB or {}
    C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    pulisciVecchi()
    -- raid portati dal ponte (file ERT_Dati.lua, scritto dal programma sul PC)
    if type(_G.ERT_Ponte) == "table" and type(_G.ERT_Ponte.righe) == "table" then
      for _, riga in ipairs(_G.ERT_Ponte.righe) do
        local r = leggiRiga(riga)
        if r and r.inizio + 4 * 3600 > time() then
          local prima = DB.raids[r.id]
          r.avvisi = prima and prima.avvisi or {}
          r.mio = true
          DB.raids[r.id] = r
        end
      end
    end
    mostraScheda("raid"); f:Hide()
    local LDB = LibStub and LibStub("LibDataBroker-1.1", true)
    icona = LibStub and LibStub("LibDBIcon-1.0", true)
    if LDB and icona then
      broker = LDB:NewDataObject("ERT", {
        type = "launcher", label = "ERT", icon = "Interface\\Icons\\Ability_Warrior_RallyingCry",
        OnClick = function(_, tasto)
          if tasto == "RightButton" then accendi(not attivo()) else f:SetShown(not f:IsShown()) end
        end,
        OnTooltipShow = function(tt)
          tt:AddLine("ERT · Ethereum Raid Tools")
          tt:AddLine(attivo() and "|cff0cd29fAcceso|r" or "|cff999999Spento|r", 1, 1, 1)
          local r = corrente()
          if r then tt:AddLine(("%s %s, ritrovo %s"):format(r.raid, date("%d/%m", r.inizio), date("%H:%M", r.ritrovo or r.inizio)), 1, 1, 1) end
          tt:AddLine("Clic: apri   ·   Clic destro: accendi / spegni", 0.7, 0.7, 0.7)
        end,
      })
      icona:Register("ERT", broker, ERTIconDB)
      ERT_AggiornaMinimappa()
    end
    C_Timer.NewTicker(15, function()
      controllaAvvisi()
      local ora = time()
      for _, r in pairs(DB.raids) do
        if r.mio and ora < r.inizio and ora - (r.mandato or 0) > 300 then manda(r) end
        local rit = r.ritrovo or (r.inizio - 1800)
        r.avvisi = r.avvisi or {}
        if attivo() and sonoReferente(r) and ora >= rit and ora < r.inizio and not r.avvisi.popup and DB.auto ~= r.id then
          r.avvisi.popup = true
          mostraPopupInviti(r)
        end
      end
      if DB.auto then
        local r = DB.raids[DB.auto]
        if not r or not sonoReferente(r) or not attivo() then DB.auto = nil
        elseif ora >= r.inizio then
          DB.auto = nil
          avvisa(("Inviti automatici finiti: %s sta per iniziare."):format(r.raid))
        else
          giro = giro + 1
          if giro % 2 == 0 and IsInGuild() then C_GuildInfo.GuildRoster() end
          invitaOnline(r, true)
        end
      end
      aggiorna()
    end)
    C_Timer.After(5, controllaAvvisi)
  elseif evento == "CHAT_MSG_ADDON" and a1 == PREFIX then
    ricevi(a2, a4)
    aggiorna()
  elseif evento == "CHAT_MSG_SYSTEM" and DB and DB.auto and attivo() then
    local nome = a1:match("|Hplayer:([^:|]+)") or a1:match("^(%S+) has come online")
    if nome and a1:find("online") then
      local r = DB.raids[DB.auto]
      nome = pulisciNome(nome)
      if r and sonoReferente(r) and time() < r.inizio and (postiDi(r)[nome] or 0) > 0 then C_Timer.After(2, function() invita(nome) end) end
    end
  elseif evento == "GROUP_ROSTER_UPDATE" then
    if GetTime() - ultimoInvito < 600 then convertiInRaid() end
    aggiorna()
  elseif evento == "GUILD_ROSTER_UPDATE" then
    aggiorna()
  end
end)

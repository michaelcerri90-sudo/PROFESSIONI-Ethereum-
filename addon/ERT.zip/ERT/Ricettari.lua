-- ERT - ricettari: quando apri la finestra di una professione, ERT si segna le ricette di quel personaggio
-- (nome, categoria, imparata o no, colore, quantita', materiali) in ERTDB.ricettari.
-- Le legge ERT-Ponte dal file salvato (al /reload o all'uscita) e le mette sul sito della gilda,
-- cosi' i ricettari funzionano con qualunque addon di professioni, anche senza nessuno.
-- Non chiede niente al server e non tocca la finestra: legge solo quello che il gioco gia' mostra.

local RACCOLTA = { Herbalism = true, Skinning = true, Fishing = true, Mining = true, ["First Aid"] = true }
-- nomi inglesi per linea di abilita' (il sito usa quelli, qualunque sia la lingua del gioco)
local PER_LINEA = {
  [171] = "Alchemy", [164] = "Blacksmithing", [333] = "Enchanting", [202] = "Engineering",
  [165] = "Leatherworking", [197] = "Tailoring", [185] = "Cooking", [129] = "First Aid",
  [186] = "Mining", [182] = "Herbalism", [393] = "Skinning", [356] = "Fishing",
  [755] = "Jewelcrafting", [773] = "Inscription",
}
local PER_NOME = {}
for _, n in pairs(PER_LINEA) do PER_NOME[n] = n end
for en, nomi in pairs({
  Alchemy = { "Alchimia", "Alchimie", "Alquimia" }, Blacksmithing = { "Forgiatura", "Schmiedekunst", "Forge", "Herrería", "Ferraria" },
  Enchanting = { "Incantamento", "Verzauberkunst", "Enchantement", "Encantamiento", "Encantamento" },
  Engineering = { "Ingegneria", "Ingenieurskunst", "Ingénierie", "Ingeniería", "Engenharia" },
  Leatherworking = { "Conciatura", "Lederverarbeitung", "Travail du cuir", "Peletería", "Couraria" },
  Tailoring = { "Sartoria", "Schneiderei", "Couture", "Sastrería", "Alfaiataria" },
  Cooking = { "Cucina", "Kochkunst", "Cuisine", "Cocina", "Culinária" },
}) do for _, n in ipairs(nomi) do PER_NOME[n] = en end end
local COLORE = { [0] = "optimal", "medium", "easy", "trivial" }

local function inglese(nome, linea) return (linea and PER_LINEA[linea]) or (nome and PER_NOME[nome]) or nome end

local function categoria(T, id)
  if not (id and T.GetCategoryInfo) then return nil end
  local ok, c = pcall(T.GetCategoryInfo, id)
  return ok and c and c.name or nil
end

-- livello "skill/max" della professione
local function livello(base, en)
  if base and tonumber(base.skillLevel) and tonumber(base.maxSkillLevel) and base.maxSkillLevel > 0 then
    return ("%d/%d"):format(base.skillLevel, base.maxSkillLevel)
  end
  if GetProfessions and GetProfessionInfo then
    for _, i in pairs({ GetProfessions() }) do
      local ok, nome, _, liv, max, _, _, linea = pcall(GetProfessionInfo, i)
      if ok and nome and inglese(nome, linea) == en and liv then return ("%d/%d"):format(liv, max or 0) end
    end
  end
  return ""
end

local function pulisci(s) return (tostring(s or ""):gsub("[|\n\r]", " ")) end

local function leggi()
  local T = C_TradeSkillUI
  if not (T and T.GetAllRecipeIDs and T.GetRecipeInfo and T.GetBaseProfessionInfo) then return end
  if (T.IsTradeSkillLinked and T.IsTradeSkillLinked()) or (T.IsTradeSkillGuild and T.IsTradeSkillGuild())
    or (T.IsNPCCrafting and T.IsNPCCrafting()) then return end
  local base = T.GetBaseProfessionInfo()
  if not (base and base.professionName and base.professionName ~= "") then return end
  local en = inglese(base.professionName, base.professionID)
  if not en or RACCOLTA[en] then return end
  local ids = T.GetAllRecipeIDs() or {}
  if #ids == 0 then return end
  -- la finestra puo' avere ancora per un attimo le ricette della professione di prima: allora riprovo dopo
  if T.GetProfessionInfoByRecipeID then
    local ok, p = pcall(T.GetProfessionInfoByRecipeID, ids[1])
    if ok and p and (p.professionName or p.parentProfessionName) then
      local giusta = false
      for _, n in pairs({ p.professionName, p.parentProfessionName }) do
        if n and n ~= "" and (n == base.professionName or n:find(base.professionName, 1, true)) then giusta = true end
      end
      if not giusta then return "riprova" end
    end
  end
  local righe = {}
  for _, id in ipairs(ids) do
    local ok, info = pcall(T.GetRecipeInfo, id)
    if ok and info and info.name then
      local q, mat = 1, {}
      local ok2, s = pcall(T.GetRecipeSchematic, id, false)
      if ok2 and s then
        if s.quantityMin and s.quantityMin > 0 then q = s.quantityMin end
        for _, slot in ipairs(s.reagentSlotSchematics or {}) do
          local base_ = not Enum.CraftingReagentType or slot.reagentType == Enum.CraftingReagentType.Basic
          local r = slot.reagents and slot.reagents[1]
          if base_ and r and r.itemID then mat[#mat + 1] = r.itemID .. ":" .. (slot.quantityRequired or 1) end
        end
      end
      righe[#righe + 1] = table.concat({ pulisci(info.name), pulisci(categoria(T, info.categoryID) or "Ricette"),
        info.learned and "1" or "0", COLORE[info.relativeDifficulty] or "", tostring(q), table.concat(mat, ",") }, "|")
      if #righe >= 600 then break end
    end
  end
  if #righe == 0 then return end
  local pg = UnitName("player")
  ERTDB = ERTDB or {}
  ERTDB.ricettari = ERTDB.ricettari or {}
  ERTDB.ricettari[pg .. "|" .. en] = { pg = pg, prof = en, livello = livello(base, en), scanned = time(), r = righe }
end

local attesa, tentativi = false, 0
local function presto()
  if attesa then return end
  attesa = true
  C_Timer.After(1, function()
    attesa = false
    local ok, esito = pcall(leggi)
    if ok and esito == "riprova" and tentativi < 4 then tentativi = tentativi + 1; presto() else tentativi = 0 end
  end)
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED" }) do
  pcall(ev.RegisterEvent, ev, e)
end
ev:SetScript("OnEvent", presto)

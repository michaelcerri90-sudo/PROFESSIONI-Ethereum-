-- Questo file lo scrive il "ponte" (il programma sul PC che parla col bot di Discord).
-- Senza ponte resta vuoto: i raid arrivano incollando la stringa del bot in /ert.
ERT_Ponte = nil
